wabs_dist <- function(u,v,w){
  return (sum(((abs(u-v))*w)));
}

create_dm <- function(x, weight){
  temp <- as.matrix(x,rownames.force = NA)
  
  final<-c()
  for(i in 1:nrow(temp)){
    for(j in 1:nrow(temp)){
      row <- unname(unlist(temp[i,]))
      row2 <- unname(unlist(temp[j,]))
      a <- wabs_dist(row,row2,weight)
      final <- c(final, a)
    }
  }
  return(matrix(final, nrow=nrow(temp), ncol=nrow(temp)))
}


purity <- function(a,b,outliers= FALSE){
  #given apriori given set of class labels =a
  #b is the “ground truth”
  total= 0
  
  
  for(int in a){
    if(int != 0){
      total = total+1
    }
  }
  
  purityresult = sum(apply(table(b,a,exclude =0),2,max))/total
  
  if(outliers){
    numout =0
    for(int in a){
      if(int == 0){
        numout = numout +1
      }
    }
    
    return(c(purityresult,numout/total))
    
  }else{
    return(purityresult)
  }
  
}


Zpima<-scale(Pima[,-9])

Zpima.lm <- lm(class~.,data = Zpima,family = binomial)

create_dm(Zpima[,-9],Zpima[,9])



summary(Zpima.lm)

#purity(Zpima[,9],Zpima)

clusters <- kmeans(Zpima,5)
clusters <- kmeans(Zpima,8)
clusters <- kmeans(Zpima, 5,nstart = 20)

pam(Zpima,5)


#weight vectors
a= c(1,1,1,1,1,1,1,1)
b= c(0.2,1,0,0,0,1,0.2,0.2)
c= c(0,1,0,1,0,1,0,0)




library(dbscan)
kNNdistplot(Zpima[-9],k=5)

abline(h=2.8, lty=1)

dbscan(Zpima[-9], eps = 2.8,minPts = 1)

fviz_cluster(dbscan(Zpima[-9], eps = 2.8,minPts = 1), Pima[-9], stand = FALSE, frame = FALSE, geom = 'point', xlab ='plasma/glucose', ylab = 'Body Mass Index')

purity(unlist(Pima[,9]),dbscan(Zpima[2:3],2.8,1)$cluster)
#purity(dbscan(Zpima[2:3],2.8,1)$cluster,Pima[,9])

#need to visualize
library(gplots)
library(ggfortify)
autoplot(fanny(Zpima[2:3],3),frame = TRUE)



clusters <- kmeans(diamond[-3], 9,nstart = 20)

purity(unlist(diamond[3]),clusters$cluster)


clusters <- kmeans(diamond[-3], 12,nstart = 20)

purity(unlist(diamond[3]),clusters$cluster)

kNNdistplot(diamond[-3],k=5)
dbscan(diamond[-3],0.13,2)

purity(unlist(diamond[,3]),dbscan(diamond[,-3],0.13,2)$cluster)

clusplot(diamond[,-3], dbscan(diamond[-3],0.13,2)$cluster, color=TRUE, shade=TRUE, labels=2, lines=0)
?clusplot

