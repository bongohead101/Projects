#1.

multi.fun <- function(x) {
  c(min = min(x), mean = mean(x), max = max(x),SD = sd(x))
}

sapply(GS,multi.fun)

plot(GS)

#0.
GS = student_por[,c(31,32,33)]

GS[which(GS[,3] == 0 &(GS[,1]!=0 |GS[,2]!=0)),]
GS = GS[-c(which(GS[,3] == 0 &(GS[,1]!=0 |GS[,2]!=0))),]
#deleted 15 rows with impossible values
GS[which(GS[,3] == 0 &(GS[,1]!=0 |GS[,2]!=0)),]
student_por = student_por[-which(student_por[,33] == 0 &(student_por[,31]!=0 |student_por[,32]!=0)),]
sapply(GS,multi.fun)


#1.
cov(GS)

cor(GS)

pairs(GS)

#2.

par(mfrow=c(1,2))

plot(GS$G1,GS$G3)
plot(GS$G1,GS$G2)

par(mfrow=c(1,1))

#3.
att5 = student_por[,c(8,9,14,15,26,31,32,33)]

par(mfrow=c(2,3))

hist(att5$Fedu , xlab = "Fathers education", ylab = "count", main = "Fedu")
barplot(table(att5$Mjob) , xlab = "mothers job", ylab = "Job", main = "Mjob")
hist(att5$studytime, xlab = "study hours", ylab = "count", main = "studytime")
hist(att5$failures , xlab = "num Past failures", ylab = "count", main = "failures")
hist(att5$goout , xlab = "out with friends", ylab = "Level", main = "goout")

par(mfrow=c(2,3))

#att5[which(att5[,8] >12),]
hist(att5[which(att5[,8] >12),]$Fedu , xlab = "Fathers education", ylab = "count", main = "Fedu")
barplot(table(att5[which(att5[,8] >12),]$Mjob) , xlab = "mothers job", ylab = "Job", main = "Mjob")
hist(att5[which(att5[,8] >12),]$studytime, xlab = "study hours", ylab = "count", main = "studytime")
hist(att5[which(att5[,8] >12),]$failures , xlab = "num Past failures", ylab = "count", main = "failures")
hist(att5[which(att5[,8] >12),]$goout , xlab = "out with friends", ylab = "Level", main = "goout")

par(mfrow=c(2,3))
#att5[which(att5[,8] <= 12),]
hist(att5[which(att5[,8] <= 12),]$Fedu , xlab = "Fathers education", ylab = "count", main = "Fedu")
barplot(table(att5[which(att5[,8] <= 12),]$Mjob) , xlab = "mothers job", ylab = "Job", main = "Mjob")
hist(att5[which(att5[,8] <= 12),]$studytime, xlab = "study hours", ylab = "count", main = "studytime")
hist(att5[which(att5[,8] <= 12),]$failures , xlab = "num Past failures", ylab = "count", main = "failures")
hist(att5[which(att5[,8] <= 12),]$goout , xlab = "out with friends", ylab = "Level", main = "goout")

par(mfrow=c(1,1))

#4.
absences = student_por[,c(30:33)]
boxplot(absences)

#5.
par(mfrow=c(2,2))
plot(student_por$G3~student_por$studytime)
plot(student_por$G3~student_por$failures)
plot(student_por$G3~student_por$goout)
plot(student_por$G3~student_por$absences)

par(mfrow=c(1,1))

#6.
holder = student_por
transform(holder, Mjob = as.numeric(Mjob))
#changing mjob teacher =1, health =2, civil 'services'=3, home =4, other =5
holder[which(holder[,9] == "teacher"),]$Mjob = 1
holder[which(holder[,9] == "health"),]$Mjob = 2
holder[which(holder[,9] == "services"),]$Mjob = 3
holder[which(holder[,9] == "at_home"),]$Mjob = 4
holder[which(holder[,9] == "other"),]$Mjob = 5

library("gplots")
hist2d(student_por$Fedu,as.numeric(holder$Mjob),xlab = "fedu",ylab = "Mjob")
hist2d(student_por$goout,student_por$failures, xlab = "goout",ylab = "failures")
hist2d(student_por$studytime,student_por$G3,xlab = "studytime",ylab = "G3")


#7.
holder = student_por

#library("data.table")
#setDT(holder)[, c(levels(holder$Mjob), "c") := c(lapply(levels(c), function(x) as.integer(x == holder$Mjob)), .(NULL))]
#cbind(holder[1:8], sapply(levels(holder$Mjob), function(x) as.integer(x == holder$Mjob)), holder[10:33])


holder = student_por

#adding columns
holder$Mjob.at_home <- holder$Mjob 
holder$Mjob.other <- holder$Mjob 
holder$Mjob.services <- holder$Mjob 
holder$Mjob.health <- holder$Mjob 
holder$Mjob.teacher <- holder$Mjob 

#making binary
holder[which(holder[,9] == "at_home"),]$Mjob.at_home = 1
holder[which(holder[,9] != "at_home"),]$Mjob.at_home = 0

holder[which(holder[,9] == "other"),]$Mjob.other = 1
holder[which(holder[,9] != "other"),]$Mjob.other = 0

holder[which(holder[,9] == "services"),]$Mjob.services = 1
holder[which(holder[,9] != "services"),]$Mjob.services = 0

holder[which(holder[,9] == "health"),]$Mjob.health = 1
holder[which(holder[,9] != "health"),]$Mjob.health = 0

holder[which(holder[,9] == "teacher"),]$Mjob.teacher = 1
holder[which(holder[,9] != "teacher"),]$Mjob.teacher = 0

holder$reason.home <- holder$reason 
holder$reason.reputation <- holder$reason 
holder$reason.course <- holder$reason 
holder$reason.other <- holder$reason 

holder[which(holder[,11] == "other"),]$reason.other = 1
holder[which(holder[,11] != "other"),]$reason.other = 0

holder[which(holder[,11] == "home"),]$reason.home = 1
holder[which(holder[,11] != "home"),]$reason.home = 0

holder[which(holder[,11] == "reputation"),]$reason.reputation = 1
holder[which(holder[,11] != "reputation"),]$reason.reputation = 0

holder[which(holder[,11] == "course"),]$reason.course = 1
holder[which(holder[,11] != "course"),]$reason.course = 0


G3.lm = lm(G3~studytime+failures+goout+absences+G1+G2+Mjob.at_home+Mjob.other+Mjob.services+Mjob.health+Mjob.teacher+reason.other+reason.home+reason.reputation+reason.course,data = holder)
plot(G3.lm)
mean(G3.lm[,1])

G3.lm$coefficients
summary(G3.lm)$r.squared
summary(G3.lm)

#most significant vars
#G32.lm = lm(G3~failures+G1+G2+reason.other+absences, data = holder)
#summary(G32.lm)$r.squared

G32.lm = lm(G3~failures+G1+Mjob.other+Mjob.services+Mjob.health+Mjob.teacher+reason.other+reason.reputation+reason.course,data = holder)
G32.lm$coefficients
summary(G32.lm)$r.squared

#8
student_por$Grade <- student_por$G3
student_por[which(student_por[,34] > 15 ),]$Grade = "A"
student_por[which(student_por[,34] == 15 | student_por[,34] == 14 ),]$Grade = "B"
student_por[which(student_por[,34] == 13 | student_por[,34] == 12 ),]$Grade = "C"
student_por[which(student_por[,34] == 11 | student_por[,34] == 10 ),]$Grade = "D"
student_por[which(student_por[,34] < 10 ),]$Grade = "F"

#changing Grade to number A=1,B=2.C=3,D=4,F=5

student_por[which(student_por[,34] < 10 ),]$Grade = 5
student_por[which(student_por[,34] == 11 | student_por[,34] == 10 ),]$Grade = 4
student_por[which(student_por[,34] == 13 | student_por[,34] == 12 ),]$Grade = 3
student_por[which(student_por[,34] == 15 | student_por[,34] == 14 ),]$Grade = 2
student_por[which(student_por[,34] > 15 ),]$Grade = 1


#80% of data
trainingdata = student_por[-c(300:427),]
#20% of data
testdata = student_por[300:427,]


library(party)
library(caret)

modela<-ctree(Grade ~ failures+absences+goout,data = testdata, controls = ctree_control(maxdepth=20))
plot(modela)

predicteda <- predict(modela,testdata)
confmat <- table(predict(modela),testdata$Grade)
accuracya <- sum(diag(confmat))/sum(confmat)

modelb<-ctree(Grade ~ freetime+studytime+age,data = testdata, controls = ctree_control(maxdepth=20))
plot(modelb)
predictedb <- predict(modelb,testdata)
confmat <- table(predict(modelb),testdata$Grade)
accuracyb <- sum(diag(confmat))/sum(confmat)

modelc <- ctree(Grade ~ age+health+absences+studytime+failures,data = testdata, controls = ctree_control(maxdepth=20))
plot(modelc)
predictedc <- predict(modelc,testdata)
confmat <- table(predict(modelc),testdata$Grade)
accuracyc <- sum(diag(confmat))/sum(confmat)


