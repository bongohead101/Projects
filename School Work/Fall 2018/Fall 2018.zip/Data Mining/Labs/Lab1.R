data.frame(Species = "setosa")

setosa <- iris[which(iris$Species == 'setosa',),]
summary(setosa$Sepal.Width)
var(setosa$Petal.Width)
sd(setosa$Petal.Width)

sandv<- iris[which(iris$Species == 'setosa' | iris$Species == 'virginica',),]

plot(Sepal.Length, Sepal.Width)

library("gplots")
hist2d(Sepal.Length,Sepal.Width)

Sepal.lm <- lm(Sepal.Length~Sepal.Width)

library("party")
plot(Sepal.Length,Sepal.Width,main="Regression of y on x",abline(Sepal.lm))



ctree(Sepal.lm)
