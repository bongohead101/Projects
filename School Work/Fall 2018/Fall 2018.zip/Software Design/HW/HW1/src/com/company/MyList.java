package com.company;
public class MyList {
    /**
     * Returns a list of the selected indexes
     *
     * This function returns a list of objects from a selected range of another list
     *
     * @param start list Parameter must contain items
     *
     * @param startpos initial position of included element;
     *             must be non-negative and within the original lists index
     *
     * @param finpos final position of included elements;
     *              must be non-negative and greater than or equal to the initial position
     *
     * @return A list of the elements in the selected indexes
     *
     * @throws IndexOutOfBoundsException if the index is out of range
     *              ({@code index < 0 || index >= this.size()})
     *
     *
     */
    public static <list> void split(list start, int startpos, int finpos){
        //return list;
    }
}


