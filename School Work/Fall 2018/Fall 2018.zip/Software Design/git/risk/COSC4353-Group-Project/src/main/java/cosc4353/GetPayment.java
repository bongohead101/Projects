package cosc4353;

public interface GetPayment {
	
	public int givePlayerCredit();
}
