package cosc4353;

public interface Action {
	public void execute();
	public void undo();
}