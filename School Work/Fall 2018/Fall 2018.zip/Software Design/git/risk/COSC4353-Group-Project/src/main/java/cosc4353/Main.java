package cosc4353;

public class Main {

	public static void main(String[] args) {
		Engine Driver = new Engine();
		Driver.StartUp();
		Driver.Turns();
	}
}