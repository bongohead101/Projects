library(ISLR)
set.seed(1)
train = sample(392,196)

library(boot)
View(Auto)

boot.fn=function(data,index) 
  return(coef(lm(mpg~horsepower,data=data,subset=index)))

#hp.lm = lm(horsepower~mpg,data = Auto)

boot.fn(Auto, 1:392)

set.seed(1)

boot.fn(Auto,sample(392,392,replace=T))
#boot.fn(Auto,index)

boot.fn(Auto,sample(392,392,replace=T))
#boot.fm(Auto,index)

boot(Auto, boot.fn,R=1000)

set.seed(1)

boot.fn=function(data,index)
     coefficients(lm(mpg~horsepower+I(horsepower^2),data=data,subset=index))


set.seed(1)

train = sample(392,196)

lm.fit=lm(mpg~horsepower,  data=Auto,subset=train)
attach(Auto)
mean((mpg-predict(lm.fit,Auto))[-train]^2)

lm.fit2=lm(mpg~poly(horsepower,2),data=Auto, subset=train)
mean((mpg-predict(lm.fit2,Auto))[-train]^2)

lm.fit3=lm(mpg~poly(horsepower,3),data=Auto, subset=train)
mean((mpg-predict(lm.fit3,Auto))[-train]^2)


