x <- c(1,3,2,5)
x

x = c(1,6,2)
x

#Task 1
y = c(1,4,3)
y

length(x)

length(y)

x+y
#Task 2 x-y
x-y

?matrix

x= matrix(data =c(1,2,3,4),nrow=2,ncol=2)
x

x=matrix(c(1,2,3,4),2,2)

matrix(c(1,2,3,4),2,2,byrow = TRUE)

sqrt(x)

x^2

#Task 3 -1/3
x^{1/3}

x=rnorm(50)
x

y=x+rnorm(50,mean = 50,sd=.1)
y

#Task 4 execute rnorm(50) twice
rnorm(50)
rnorm(50)

set.seed(2)
rnorm(50)

#test 5 which sequences are the same
set.seed(1)
rnorm(5)
rnorm(5)
set.seed(1)
rnorm(5)

set.seed(1303)
rnorm(50)

set.seed(3)
y=rnorm(1000)
mean(y)
var(y)
sqrt(var(y))
sd(y)

x=rnorm(100)
y=rnorm(100)
plot(x,y)
plot(x,y,xlab = "This is the x-axis",ylab = "This is the y-axis",main = "Plot of x vs y")

#task 6
x=rnorm(100)
y=rnorm(100)
plot(x,y,xlab = "Heeey (x)",ylab = "Hooo (y)",main = "HEEEY (main)")


