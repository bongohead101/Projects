library(MASS)
library(tree)

set.seed(1)
train = sample(1:nrow(Boston),nrow(Boston)/2)

tree.boston = tree(medv~.,data = Boston,subset=train)
summary(tree.boston)

set.seed(1)
train = sample(1:nrow(Boston),nrow(Boston)/2)
bag.boston = randomForest(medv~.,data = Boston,subset = train,ntree =100,mtry=13,importance = TRUE)
bag.boston

yhat = predict(tree.boston, newdata=Boston[-train,])
boston.test = Boston[-train, "medv"]
plot(yhat, boston.test)
abline(0,1)
mean((yhat-boston.test)^2)

yhat.bag = predict(bag.boston,newdata=Boston[-train,])
plot(yhat.bag, boston.test)
abline(0,1)
mean((yhat.bag-boston.test)^2)


