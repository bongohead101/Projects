library("ISLR")
View(Smarket)
attach(Smarket)

dim(Smarket)
summary(Smarket)

cor(Smarket)
cor(Smarket[,-9])

glm.fit = glm(Direction ~ Lag1 + Lag2 + Lag3 + Lag4 + Lag5 + Volume, data = Smarket, family = binomial)
summary(glm.fit)
summary(glm.fit)$coef
summary(glm.fit)$coef[,4]

glm.probs = predict(glm.fit, type = "response")
glm.probs[1:10]

contrasts(Direction)

predict(glm.fit, type="response", newdata = data.frame(Lag1 =0.5, Lag2 = -0.5,
                                                         Lag3= 0.5, Lag4=-0.5,
                                                         Lag5= 0.5,
                                                         Volume=2))

glm.predict = rep("Down",1250)
glm.predict[glm.probs>.5] = "Up"


table(glm.predict,Direction)
s
mean(glm.predict == Smarket$Direction)

