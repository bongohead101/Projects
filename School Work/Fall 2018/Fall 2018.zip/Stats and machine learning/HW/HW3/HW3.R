library(ISLR)
View(Weekly)

summary(Weekly)

cor(Weekly[,-9])
pairs(Weekly[,-9])

nrow(Weekly[which(Weekly[,9]== "Up"),])
nrow(Weekly[which(Weekly[,9]== "Down"),])

min(Weekly[which(Weekly[,9]== "Up"),],Weekly[,7])
max(Weekly[which(Weekly[,9]== "Up"),],Weekly[,7])

glm.fit = glm(Direction ~ Lag1+Lag2+Lag3+Lag4+Lag5+Volume, data=Weekly, family=binomial)
summary(glm.fit)

attach(Weekly)
attach(data)
library(boot)
itrain <- createDataPartition(y = Direction, p = 0.75, list = FALSE)
train <- Weekly[itrain,]
test <- Weekly[-itrain,]

probs <- predict(glm.fit, type = "response")
pred.glm <- rep("Down", length(probs))
pred.glm[probs > 0.5] <- "Up"
table(pred.glm, Direction)

attach(Weekly)
#train <- (Weekly[which(Weekly$Year <= 2006 && Weekly$Year >=1990)])
train <- (Year < 2007)
Weekly.19902006 <- Weekly[!train, ]
Direction.19902006 <- Direction[!train]
fit.glm2 <- glm(Direction ~ Lag2, data = Weekly, family = binomial, subset = train)
summary(fit.glm2)

probs2 <- predict(fit.glm2, Weekly.19902006, type = "response")
pred.glm2 <- rep("Down", length(probs2))
pred.glm2[probs2 > 0.5] <- "Up"
table(pred.glm2, Direction.19902006)


Power2 <- function(x,y){
  final = x^y
  
  print(final)
}

Power2(2,3)
Power2(3,8)

Power2(10,3)
Power2(8,17)
Power2(131,3)

Power3 <- function(x,y){
  result = x^y
  return(result)
}

plot(Power3(c(1:10),2),xlab = "1-10",ylab = "^2 value", main = "X^2 curve")

PlotPower <- function(x,y){
  plot(Power3(x,y))
}

PlotPower(c(1:10),3)


library(MASS)
attach(Boston)
View(Boston)
Boston$crim <- (crim > median(crim)) # Converting ’crim’ variable into binary.
Boston$crim <- ifelse(Boston$crim,1,0)

summary(glm(crim~.,data = Boston,family = binomial))

summary(glm(crim~rad+nox,data = Boston,family = binomial))

set.seed(1)
trainingrows = sample(nrow(Boston),nrow(Boston)/2,replace = FALSE)
train = Boston[trainingrows,]
test = Boston[-trainingrows,]

Boston.lm = glm(crim~.,data = train,family = binomial)
Boston.fixed.lm = glm(crim~rad+nox,data = train,family = binomial)

probs <- predict(Boston.lm, test, type = "response")
probsfixed <- predict(Boston.fixed.lm, test, type = "response")

pred.glm <- rep(0, length(probs))
pred.glm[probs > 0.5] <- 1

predfixed.glm <- rep(0, length(probsfixed))

predfixed.glm[probsfixed > 0.5] <- 1

table(pred.glm, test$crim)
table(predfixed.glm, test$crim)

(table(pred.glm, test$crim)[2,1] + table(pred.glm, test$crim)[1,2])/sum(table(pred.glm, test$crim)[,1])

(table(predfixed.glm, test$crim)[2,1] + table(predfixed.glm, test$crim)[1,2])/sum(table(predfixed.glm, test$crim)[,1])


Boston.lm = glm(crim~.,data = Boston,family = binomial)
Boston.fixed.lm = glm(crim~rad+nox,data = Boston,family = binomial)

cv.error = cv.glm(Boston,Boston.lm)
cv.error$delta[1]
cv.error = cv.glm(Boston,Boston.fixed.lm)
cv.error$delta[1]

set.seed(1)
cv.error = rep(0,5)

for (i in 1:10) {
  Boston.lm = glm(crim~poly(zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+black+lstat+medv,i),data = Boston,family = binomial)
  cv.error[i] = cv.glm(Boston, Boston.lm)$delta[1]
}

cv.error

cv.error = rep(0,5)
for (i in 1:10) {
  Boston.fixed.lm = glm(crim~poly(rad+nox,i),data = Boston,family = binomial)
  cv.error[i] = cv.glm(Boston, Boston.fixed.lm)$delta[1]
}

cv.error

View(Default)

Default$default <- ifelse(Default$default == "Yes",1,0)

Default.lm = glm(default~income+balance,data = Default,family = binomial)
summary(Default.lm)


boot.fn=function(data,index){
  return(coef(glm(default~income+balance,data=data,subset=index)))
}

boot.fn(Default,1:10000)

boot(Default,boot.fn,R = 100)

set.seed(1)

for (i in 1:10){
  model_GLR = glm(default~poly(income+balance,i), data=Default)
  print(cv.glm(Default, model_GLR, K=10)$delta)
}

