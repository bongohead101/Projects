library(ISLR)
library(tree)
library(boot)
library(caret)

set.seed(1)
train <- sample(1:nrow(Carseats), nrow(Carseats) / 2)
Carseats.train <- Carseats[train, ]
Carseats.test <- Carseats[-train, ]

tree.carseats <- tree(Sales ~ ., data = Carseats.train)

summary(tree.carseats)

yhat <- predict(tree.carseats, newdata = Carseats.test)
mean((yhat - Carseats.test$Sales)^2)

cv.carseats <- cv.tree(tree.carseats)
plot(cv.carseats$size, cv.carseats$dev, type = "b")
tree.min <- which.min(cv.carseats$dev)
#points(tree.min, cv.carseats$dev[tree.min], col = "red", cex = 2, pch = 20)

prune.carseats <- prune.tree(tree.carseats, best = 8)
plot(prune.carseats)
text(prune.carseats, pretty = 0)

#finds error
yhat <- predict(prune.carseats, newdata = Carseats.test)
mean((yhat - Carseats.test$Sales)^2)

library(randomForest)

bag.carseats <- randomForest(Sales ~ ., data = Carseats.train, mtry = 10, ntree = 500, importance = TRUE)
yhat.bag <- predict(bag.carseats, newdata = Carseats.test)
mean((yhat.bag - Carseats.test$Sales)^2)

importance(bag.carseats)

rf.carseats <- randomForest(Sales ~ ., data = Carseats.train, mtry = 3, ntree = 500, importance = TRUE)
yhat.rf <- predict(rf.carseats, newdata = Carseats.test)
mean((yhat.rf - Carseats.test$Sales)^2)

importance(rf.carseats)


View(Caravan)

set.seed(1)
train <- sample(1:nrow(Caravan), nrow(Caravan)/2)
Caravan.train <- Caravan[train, ]
Caravan.test <- Caravan[-train, ]

tree.caravan <- tree(Purchase ~ ., data = Caravan.train)
tree.caravan
summary(tree.carseats)

plot(tree.caravan)
text(tree.caravan, pretty = 0)

tree.pred <- predict(tree.caravan, Caravan.test, type = "class")
table(tree.pred, Caravan.test$Purchase)

1-(2727+4)/(2727+5+4+175)

cv.caravan <- cv.tree(tree.caravan, FUN = prune.misclass)
cv.caravan

plot(cv.caravan$size, cv.caravan$dev, type = "b", xlab = "Tree size", ylab = "Deviance")

prune.caravan <- prune.misclass(tree.caravan, best = 4)
plot(prune.caravan)
text(prune.caravan, pretty = 0)

summary(tree.caravan)
summary(prune.caravan)

prune.pred <- predict(prune.caravan, Caravan.test, type = "class")
table(prune.pred, Caravan.test$Purchase)

1-(2727+4)/(2727+175+5+4)

View(OJ)

set.seed(1)
train <- sample(nrow(OJ), 800)
OJ.train <- OJ[train, ]
OJ.test <- OJ[-train, ]

tree.oj <- tree(Purchase ~ ., data = OJ.train)
summary(tree.oj)

tree.oj

plot(tree.oj)
text(tree.oj, pretty = 0)

tree.pred <- predict(tree.oj, OJ.test, type = "class")
table(tree.pred, OJ.test$Purchase)

1-(147+62)/(147+49+12+62)

cv.oj <- cv.tree(tree.oj, FUN = prune.misclass)
cv.oj

plot(cv.oj$size, cv.oj$dev, type = "b", xlab = "Tree size", ylab = "Deviance")

prune.oj <- prune.misclass(tree.oj, best = 2)
plot(prune.oj)
text(prune.oj, pretty = 0)

summary(tree.oj)
summary(prune.oj)

prune.pred <- predict(prune.oj, OJ.test, type = "class")
table(prune.pred, OJ.test$Purchase)

1-(119+81)/(119+30+40+81)


library(ISLR)

Hitters$LogSalary <- log(Hitters$Salary)
Hitters$Salary <- NULL
Hitters <- na.omit(Hitters)
set.seed(1)
train <- sample(nrow(Hitters), 200)

Hitters.train = Hitters[train,]
Hitter.test = Hitters[-train,]

tree.hitters = tree(LogSalary~.,data = Hitters)

summary(tree.hitters)

tree.hitters

plot(tree.hitters)
text(tree.hitters, pretty = 0)

yhat <- predict(tree.hitters, newdata = Hitter.test)
mean((yhat - Hitter.test$LogSalary)^2)

cv.hitter <- cv.tree(tree.hitters)
plot(cv.hitter$size, cv.hitter$dev, type = "b")
tree.min <- which.min(cv.hitter$dev)

prune.hitter <- prune.tree(tree.hitters, best = 6)
plot(prune.hitter)
text(prune.hitter, pretty = 0)

summary(prune.hitter)

prune.hitter <- prune.tree(tree.hitters, best = 5)
plot(prune.hitter)
text(prune.hitter, pretty = 0)

summary(prune.hitter)
summary(tree.hitters)

set.seed(1)

tree.hitters = tree(LogSalary~.,data = Hitter.test)

prune.hitter <- prune.tree(tree.hitters, best = 6)
#plot(prune.hitter)
#text(prune.hitter, pretty = 0)

summary(prune.hitter)




