attach(Auto)

#4
rel.lm = lm(mpg~horsepower)
summary(lm(mpg~horsepower))
t.test(rel.lm,conf.level = .95)
confint(rel.lm, mpg,level =0.95)

predict(rel.lm, data.frame(horsepower = 98), interval = "confidence")
predict(rel.lm, data.frame(horsepower = 98), interval = "prediction")

plot(mpg~horsepower)
abline(rel.lm)

par(mfrow =c(2,2))
plot(rel.lm)
par(mfrow=c(1,1))

Carseatsnumonly <- Carseats[,-c(7,10,11)]
pairs(Carseatsnumonly)
cor(Carseatsnumonly)

summary(lm(Sales~.-Sales,data = Carseatsnumonly))

par(mfrow =c(2,2))
plot(lm(Sales~.-Sales,data = Carseatsnumonly))
par(mfrow=c(1,1))

rel.lm = lm(Sales~Price+Income+US,data = Carseats)

contrasts(Carseats$US)

rel.lm:lm(Price~US,data = Carseats)
summary(rel.lm)
rel.lm:lm(Income~US,data = Carseats)

library("MASS")
View(Boston)

summary(lm(crim~.-crim,data = Boston))


