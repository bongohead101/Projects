fo <- function(data,weights,bias){
  sum(data*weights + bias)
}

info <- c(1,2,3,4,5)
weight <- c(.1,.1,.1,.1,.6)

fo(info,weight,.2)

info <- c(1,2,3,4,5)
weight <- c(.6,.1,.1,.1,.1)
fo(info,weight,.2)
