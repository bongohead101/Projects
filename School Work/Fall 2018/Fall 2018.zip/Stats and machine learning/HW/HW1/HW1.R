attach(College)

rownames(College) = College[ ,1]
fix(College)

College = College[ ,-1]
fix(College)

summary(College)

pairs(College[,2:10])

boxplot(College$Outstate ~ College$Private,main = "Outstate versus Private",xlab = "Private", ylab = "Outstate")

Elite = rep("No", nrow(College))
Elite[College$Top10perc>50]= "Yes"
Elite = as.factor(Elite)
College = data.frame(College, Elite)
fix(College)

summary(College)

boxplot(College$Outstate ~ College$Elite.1,main = "Outstate versus Elite",xlab = "Elite", ylab = "Outstate")

par(mfrow = c(2,2))
hist(College$Books, xlab = "Books", ylab = "Count")
hist(College$Grad.Rate, xlab = "Grad Rate", ylab = "count")
hist(College$Accept, xlab = "Accept", ylab = "Count")
hist(College$Enroll, xlab = "Enroll", ylab = "Count")

library(MASS)
Boston
?Boston

par(mfrow = c(2, 2))
plot(Boston$nox, Boston$crim)
plot(Boston$rm, Boston$crim)
plot(Boston$age, Boston$crim)
plot(Boston$dis, Boston$crim)

t(sapply(Boston,range))

multi.fun <- function(x) {
  c(mean = mean(x), sd = sd(x))
}

sapply(Boston, multi.fun)

B2 <- Boston[-10:-85,]

multi.fun <- function(x) {
  c(min = min(x), max = max(x), mean = mean(x), sd = sd(x))
}

sapply(B2, multi.fun)

library(ISLR)
Auto
?Auto
nrow(Auto)
ncol(Auto)

auto = Auto[,-2]
auto = auto[,-7]
pairs(auto)

Auto$origin <- factor(Auto$origin, levels=1:3, labels=c("U.S.", "Europe", "Japan"))
sapply(Auto, class)
quant <- sapply(Auto, is.numeric)
sapply(Auto[, quant], range)

sapply(Auto[which(Auto[,8]=="U.S."), quant], range)
sapply(Auto[which(Auto[,8]=="Europe"), quant], range)
sapply(Auto[which(Auto[,8]=="Japan"), quant], range)

length(Auto[which(Auto[,7]>80 | Auto[,7] == 80),7])

