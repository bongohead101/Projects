# -*- coding: utf-8 -*-
import sys

sys.setrecursionlimit(3250) #allows for larger numbers to be calculated in multiplication
inputfile = ""
numdigits = 1

#this function handles arguments, global variables used to avoid repeated passes of numdigits and input file
def setvals():
    arr = LinkedList()
    findsymindex(sys.argv[1],arr)
    #print("The sym list contains : ")
    #arr.printlist(arr.head)

    global inputfile
    global numdigits

    if(len(sys.argv) > 1):
        if(findparam(sys.argv[1]) == "input"):
            inputfile = findparam((sys.argv[1])[int(arr.getindex(arr.head,0))+1:])
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
	
        if(findparam((sys.argv[1])[int(arr.getindex(arr.head,1))+1:]) == "digitsPerNode"):
            numdigits = int(findparam(sys.argv[1][int(arr.getindex(arr.head,2))+1:]))
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
        
        if(numdigits <=0):
            print("digits per node cant be negative!")
            sys.exit(-2)


#returns of = or ; for argument handler
def findsymindex(argstr,llist, i=0):
    if(len(argstr) <= 0):
        return llist
    elif(argstr[0] == "=" or argstr[0] == ";"):
        llist.append(i)
        return findsymindex(argstr[1:],llist,i+1)
    else:
        return findsymindex(argstr[1:],llist,i+1)

#steps through parameter until it finds a symbol and returns the string
def findparam(arg):
    if(len(arg) <= 0):
        return ""
    elif(arg[0] == "=" or arg[0] == ";"):
        return ""
    else:
        return arg[0] + findparam(arg[1:])
        
#returns a string of a number before encountering a symbol or reaches the end
def createnum(a): 
    if (len(a) <= 0 or a[0] == "+" or a[0] == "*"):
        return ""
    elif(a[0] == " "):
        return str(createnum(a[1:]))
    elif(a[0].isdigit()):
        return a[0] + str(createnum(a[1:]))
    else:
        return ""

#returns the length of the string, used for comparing length of digits
def countstr(s):
    return len(s)

#ensures that output to console is horizontally contiguous
def printsameline(strin):
    sys.stdout.write(strin)
    sys.stdout.flush()

#removes leading zeroes    
def removeleading(strin):
    if(strin == ""):
        return""
    return str(int(strin))

#returns correct symbol when output is passed to console
def printsym(i):
    if(i==1):
        printsameline("*")
    elif(i==2):
        printsameline("+")
    else:
        printsameline("?")

#returns the index of the first non digit occurence    
def findsym(a): 
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return 1+findsym(a[1:])
    elif(a[0] == "*" or a[0] == "+"):
        return 0
    else:
        print("ERROR unknown symbol")
        return -1
        
#returns a 1 if string contains a * or a 2 if + and -1 otherwise        
def checksym(a): 
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return checksym(a[1:])
    elif(a[0] == "*"):
        return 1
    elif(a[0] == "+"):
        return 2
    else:
        print("ERROR unknown symbol")
        return -1

#creates the proper string to output    
def createresult(inputstr): 
    sym = checksym(inputstr)
    if(sym == 1):
        
        return "*"
    elif(sym == 2):
        
        return "+"
    else:
        print("Error invalid symbol")
        sys.exit(-1)

#defines the LinkedList Node class funcitons
class Node:
    
    #works as a constructor to initialize properties of Node
    def __init__(self, data=None, prev=None, next=None):
        self.data = data
        self.prev = prev
        self.next = next

    #whenever Node is printed, retrieves data
    def __repr__(self):
        return repr(self.data)
    
    #whenever addition is called, adds Node data
    def __add__(self, other):
        return self.data + other.data
    #def __mul__(self, other):
        #return self.data * other.data
        
    #call the to String function of the object inside the list which should return a string of the data
    def toString(self):
        return self.data.toString()

#defines the structure of linked list data structure used to store Node data
class LinkedList:
    #when initalizing a linked list if a string parameter is passes then it will assume it is a digits object and split it accordingly
    def __init__(self, strin = ""):
        if strin is not "":
            self.head = None
            self.tail = None
            self.count = 0;
            self.makelistdigits(strin)
            
        else:
            self.head = None
            self.tail = None
            self.count = 0;
            
    #if the list is called by its self then it will return all of the data contained
    def __repr__(self):
        def printlist(node):
            if(node.next == None):
                return node.data
            else:
                return node.data + printlist(node.next)
        
        cur = self.head
        return printlist(cur)
        
    #adds an object of any type to the front of the list
    def prepend(self, data):
        new_head = Node(data=data, next=self.head)
        if self.head:
            self.head.prev = new_head
        self.head = new_head
        self.count = self.count+1
    
    #adds an object of any type at the end of the list
    def append(self, data):
        def endnode(node): ##returns node at the end
            if(node.next == None):
                #print("found Node")
                return node
            else:
                #print(str(node.next))
                #print("Finding node.")
                return endnode(node.next)
                
        if not self.head:
            self.head = Node(data=data)
            self.count = self.count +1
            #print("Made head: "+str(self.head))
            return
        
        curr = self.head
        curr = endnode(curr)
        curr.next = Node(data=data, prev=curr)
        #print("Made node: "+str(curr.next))
        self.count = self.count +1
    
    #returns the object at a certain "index"
    def getindex(self,current, index , i = 0):
        if(current == None):
            return "-1"
        elif(index == i):
            return current.data
        else:
            return self.getindex(current.next, index ,i=i+1)
    
    #displays the data in a single line format
    def printlist(self,node = None):
        
        if node is None:
            self.Plistdefault(self.head)
        else:
            self.Plistdefault(node)
    
    # second part to printlist/ was created so that printlist could have default parameters
    def Plistdefault(self,node):
            if(node == None):
                return
            else:
                printsameline(str(node.data))#print(node)
                self.Plistdefault(node.next)
    
    # calls the to string dunction in all of the nodes
    def toString(self,node = None,strin =""):
        if node is None:
            return self.toStringdefault(self.head,strin)
        else:
            return self.toStringdefault(node,strin)
    
    # second part to toString() / was created so that recursion could be performed with default parameters
    def toStringdefault(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + node.data.toString()
                return self.toStringdefault(node.next,strin)
    
    #converts string values of linked list into digits    
    def makelistdigits(self,strin):
        if(len(strin) <= numdigits):
            self.prepend(digits(strin))
        else:
            self.prepend(digits(strin[len(strin)-(numdigits):]))
            self.makelistdigits(strin[:-numdigits])
    
    #takes two LinkedLists and adds them from end node to beginning node and returns the result        
    def listAdd(self, list1, list2, step, carry): 
        if list1 is None: #condition to check None type linked list
            return list2
        elif list2 is None:
            return list1
        elif step > list1.count and step <= list2.count: #addition when step counter exceeds length of list1 but not list2
            result = int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry #retrieves index of list2 starting from the end and adds carry digit
            if len(str(result)) > numdigits: #determines if carry is necessary for next call
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step <= list1.count and step > list2.count:
            result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + carry
            if len(str(result)) > numdigits:
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step > list1.count and step > list2.count: #returns final addition result and prepends 1 if a carry is needed
            if carry == 1: 
                self.prepend("1")
                return
            else:
                return
        #adds last number of each list to each other and steps from right to left, marking carries as needed
        result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
        if len(str(result)) > numdigits:
            self.prepend(result%10**numdigits)
            carry = 1
            return self.listAdd(list1,list2,step+1, carry)
        else:
            self.prepend(result)
            carry = 0
            return self.listAdd(list1,list2,step+1, carry)

##List values
#############################
#nums1 = LinkedList("1232")
#nums2 = LinkedList("13")

##Multiplication Placeholders
#############################
#productholder = LinkedList()
#totalholder = LinkedList("0")
#results2 = LinkedList()

##Multiplication Test
#############################
#results2.listMult(nums1,nums2,productholder,totalholder,1,1)
#results2.printlist(results2.head)        
    
    #takes two LinkedLists and multiplies them from end to beginning
    def listMult(self, list1, list2,productholder,totalholder,step1,step2):
        if list1 is None or list2 is None:
            print("Error, incorrect input")
        
        #stores string result of last digit of each number from right to left
        res1 = list1.getindex(list1.head,list1.count - step1,0).toString()
        res2 = list2.getindex(list2.head,list2.count - step2,0).toString()
        if list1.count == 1 or list2.count == 1: #handles event where one number is a single digit
            if list1.count > 1 and list2.count == 1: #steps through multiplying if one number is still larger than 1 digit size
                if step1 < list1.count: #steps through up to the second of a number, multiplies each digit by the other number and adds to totalholder
                    product = (int(res1) *10**(step1-1)) * int(res2)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    temp = LinkedList()
                    return self.listMult(list1,list2,temp,totalholder, step1+1,step2)
                elif step1 >= list1.count: #final call once last digit is reached and returns result
                    product = (int(res1) *10**(step1-1)) * int(res2)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    # print("Your result is:")
                    totalholder.printlist(totalholder.head)
                    return
            elif list1.count == 1 and list2.count > 1:
                if step2 < list2.count:
                    product = (int(res2) *10**(step2-1)) * int(res1)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    temp = LinkedList()
                    return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                    product = (int(res2) *10**(step2-1)) * int(res1)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    # print("Your result is:")
                    totalholder.printlist(totalholder.head)
                    return
            elif list1.count == 1 and list2.count == 1: #if both numbers are 1 digit length, simply multiplies and returns
                product = int(res1) * int(res2)
                self.append(str(product))
                # print("Your result is:")
                return
        elif list1.count >= list2.count: #executes multiplication for when list1 is longer or equal to list2
            if step2 < list2.count: #steps through the smaller list's digits from right to left up to the second to last digit
                if step1 < list1.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1)) #multiplies digits from right to left in list1 by list2 based on step in recursion
                        productholder = LinkedList(str(product)) #stores product of digits in list
                        self = LinkedList() #clears self LinkedList to hold new total
                        self.listAdd(totalholder,productholder,1,0) #uses listAdd function to add running total to current product
                        totalholder = LinkedList(self.toStringSlist()) #stores running total for next call
                        temp = LinkedList() #produces empty LinkedList so next productholder is empty
                        return self.listMult(list1,list2,temp,totalholder, step1+1,step2) #recursion call step one more digit left in list 1
                elif step1 >= list1.count: #final recursion call for current digit in list2
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        step1 = 1 #resets step1 for next digit from list2
                        return self.listMult(list1,list2,temp,totalholder,step1,step2+1) #returns to multiplying one digit left in list2 by all of list1
            elif step2 >= list2.count: #final recursive call for last digit of smaller list
                if step1 < list1.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1+1,step2)
                elif step1 >= list1.count: #final digit multiplication and addition to total
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        # print("Your result is:")
                        totalholder.printlist(totalholder.head)
                        return
        elif list1.count <= list2.count: #executes multiplication for when list2 is longer or equal to list1
            if step1 < list1.count:
                if step2 < list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        # print("productholder is:")
                        # productholder.printlist(productholder.head)
                        # print("\ntotalholder is:")
                        # totalholder.printlist(totalholder.head)
                        # print("\nAt loop" + str(step2))
                        # print("Your result is:")
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        # print("productholder is:")
                        # productholder.printlist(productholder.head)
                        # print("\ntotalholder is:")
                        # totalholder.printlist(totalholder.head)
                        # print("\nAt loop" + str(step2))
                        # print("Your result is:")
                        temp = LinkedList()
                        step2 = 1
                        return self.listMult(list1,list2,temp,totalholder,step1+1,step2)
            elif step1 >= list1.count:
                if step2 < list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        # print("productholder is:")
                        # productholder.printlist(productholder.head)
                        # print("\ntotalholder is:")
                        # totalholder.printlist(totalholder.head)
                        # print("\nAt loop" + str(step1))
                        # print("Your result is:")
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        # print("productholder is:")
                        # productholder.printlist(productholder.head)
                        # print("\ntotalholder is:")
                        # totalholder.printlist(totalholder.head)
                        # print("\nAt loop" + str(step1))
                        # print("Your result is:")
                        # print("Your result is:")
                        totalholder.printlist(totalholder.head)
                        return
    
    #is used if the linked list contains strings in the nodes rather than objects
    def toStringSlist(self,node = None,strin =""):
        if node is None:
            return self.toStringdefaultSlist(self.head,strin)
        else:
            return self.toStringdefaultSlist(node,strin)
            
    # second part to toStringSlist() / was created so that recursion could be performed with default parameters
    def toStringdefaultSlist(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + str(node.data)
                return self.toStringdefaultSlist(node.next,strin)
       
        
#object that stores each digit as a place in an array
class digits:
    #if given a string then it initalizes with that string contained and adds any leading zeros neccessary
    def __init__(self,strin):
        global numdigits
        self.arr = ["0"]*numdigits
        
        if(len(strin) == numdigits):
            self.setnumber(strin)
            self.cusion()
            
        elif(len(strin) > numdigits):
            print("Error Wrong sized string for digit object\t size of string given was: "+ str(len(strin)) + " Needs to be: "+ str(numdigits))
            
        else:
            self.setnumber(strin)
            self.cusion()
            
    #sets the data contained in the object given a string of the data
    def setnumber(self,strin,i=None):
        
        if i is None:
            if(len(strin)>0 and not strin ==""):
                return self.setnumber(strin,numdigits-1)
            else:
                return
        
        if(not len(strin) <= 0):
            self.arr[i] = strin[len(strin)-1]
            self.setnumber(strin[:-1],i-1)
            
    #adds in zeros where a number is not defined in the array
    def cusion(self,i=0):
        if i is None:
            return self.setnumber(numdigits-1)
        
        if(i < 0):
            return
        elif(self.arr[i] == None or self.arr[i] == ""):
            self.arr[i] = "0"
            return self.cusion(i-1)
        
    #if the object is called by its self then it will output the number that was given
    def __repr__(self):
        return self.getnum()
    
    def __add__(self, other):
        return int(self.getnum()) + int(other.getnum())
    
    #returns a string of the number in the array
    def getnum(self,i=0):       
        if(i<0):
            return -1
        elif(i>=numdigits-1):
            return self.arr[i]
        else:
            return self.arr[i] + self.getnum(i+1)
    
    #returns the number stored in the array but as a string
    def toString(self, strin ="",i=0):
        if (numdigits == i):
            return ""
        else:
            return self.arr[i] + self.toString(strin,i+1)
    

setvals()
#print(inputfile)
#print(numdigits)

#handles file input and loops through file      
with open(inputfile) as inputfile:
    for line in inputfile:
        num1 = createnum(line)
        num2 = createnum(line[(findsym(line)+1):])
        if(not num1 == "" and not num2 == ""):
    
            #runcode
            num1l = LinkedList(num1)
            num2l = LinkedList(num2)
            
            sign = checksym(line)
            
            if(sign == 1):
                printsameline(removeleading(num1l.toString()))
                printsym(sign)
                printsameline(removeleading(num2l.toString()))
                printsameline("=")
                
                
                
                
                
                #results = LinkedList()
                #productholder = LinkedList()
                #totalholder = LinkedList("0")
                
                #print("Numbers are: "+str(int(num1l.toString())) + " and "+ str(int(num2l.toString())))
                #results.listMult(LinkedList(str(int(num1l.toString()))),LinkedList(str(int(num2l.toString()))),productholder,totalholder,1,1)
                #print(int(results.listMult(LinkedList(num1l.toString()),LinkedList(num2l.toString()),productholder,totalholder,1,1).toStringSlist()))
                
                
                
            elif(sign == 2):
                printsameline(removeleading(num1l.toString()))
                printsym(sign)
                printsameline(removeleading(num2l.toString()))
                printsameline("=")
                
                results = LinkedList()
                results.listAdd(LinkedList(num1l.toString()),LinkedList(num2l.toString()),1,0)
                print(results.toStringSlist())
                
                ##print(result)
            else:
                print("Invalid Sign")
            
        else:
            print("Error one of the numbers is not valid")
            

