################################
#     Homework 1 COSC 4315     #
################################
Ryan Beery - 1764567 cosc2958 
Marc Cardenas - 1597234 cosc2963


The objective of this program is to exceed the regular limit applicable to arithmetic for addition and multiplication throught he use of data structures.
A brief description of each function follows below:

set of functinos to handle file input
#######################################################################################################################################################################
def setvals() - this function handles arguments, global variables used to avoid repeated passes of numdigits and input file
def findsymindex(argstr,llist, i=0) - returns of = or ; for argument handler
def findparam(arg) - steps through parameter until it finds a symbol and returns the string
def createnum(a) - returns a string of a number before encountering a symbol or reaches the end
def countstr(s) - returns the length of the string, used for comparing length of digits
def printsameline(strin) - ensures that output to console is horizontally contiguous
def removeleading(strin) - removes leading zeroes, in cases where a number may yield something such as 0500 --> 500
def printsym(i) - returns correct symbol when output is passed to console
def findsym(a) - returns the index of the first non digit occurence
def checksym(a) - returns a 1 if string contains a * or a 2 if + and -1 otherwise
def createresult(inputstr) - creates the proper string to output
#######################################################################################################################################################################

class Node - defines the LinkedList Node class funcitons
#######################################################################################################################################################################
def __init__(self, data=None, prev=None, next=None) - works as a constructor to initialize properties of Node
def __repr__(self) - whenever Node is printed, retrieves data
def __add__(self, other) - whenever addition is called, adds Node data
def toString(self) - Call the to String function of the object inside the list which should return a string of the data
#######################################################################################################################################################################

class LinkedList - defines the structure of linked list data structure used to store Node data
#######################################################################################################################################################################
def __init__(self, strin = "") - when initalizing a linked list if a string parameter is passes then it will assume it is a digits object and split it accordingly
def __repr__(self) - if the list is called by its self then it will return all of the data contained
def prepend(self, data) - adds an object of any type to the front of the list
def append(self, data) - adds an object of any type at the end of the list
def getindex(self,current, index , i = 0) - returns the object at a certain "index"
def printlist(self,node = None) - displays the data in a single line format
def Plistdefault(self,node) - second part to printlist/ was created so that printlist could have default parameters
def toString(self,node = None,strin ="") - calls the to string dunction in all of the nodes
def toStringdefault(self,node,strin) - second part to toString() / was created so that recursion could be performed with default parameters
def makelistdigits(self,strin) - converts string values of linked list into digits

#######################################################################################################################################################################
def listAdd(self, list1, list2, step, carry) - takes two LinkedLists and adds them from end node to beginning node and returns the result
    -if list1 is None:
        -condition to check None type linked list
    -elif step > list1.count and step <= list2.count:
        -addition when step counter exceeds length of list1 but not list2
    -result = int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
        -retrieves index of list2 starting from the end and adds carry digit
    -if len(str(result)) > numdigits: 
        -determines if carry is necessary for next call
    -elif step > list1.count and step > list2.count: 
        -returns final addition result and prepends 1 if a carry is needed
    -result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
        -adds last number of each list to each other and steps from right to left, marking carries as needed
#######################################################################################################################################################################

#######################################################################################################################################################################
def listMult(self, list1, list2,productholder,totalholder,step1,step2): - takes two LinkedLists and multiplies them from end to beginning
    -if list1 is None or list2 is None:
        -handles situation where an empty list is passed
    -res1 = list1.getindex(list1.head,list1.count - step1,0).toString()    
        -stores string result of last digit of each number from right to left
     -if list1.count == 1 or list2.count == 1:
        -handles event where one number is a single digit
    -if list1.count > 1 and list2.count == 1:
        -steps through multiplying if one number is still larger than 1 digit size
    -if step1 < list1.count:
        -steps through up to the second of a number, multiplies each digit by the other number and adds to totalholder
    -elif step1 >= list1.count:
        -final call once last digit is reached and returns result
    -elif list1.count == 1 and list2.count == 1:
        -if both numbers are 1 digit length, simply multiplies and returns
    -elif list1.count >= list2.count:
        -executes multiplication for when list1 is longer or equal to list2
    -if step2 < list2.count: 
        -steps through the smaller list's digits from right to left up to the second to last digit
    -product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
        -multiplies digits from right to left in list1 by list2 based on step in recursion
    -productholder = LinkedList(str(product)) 
        -stores product of digits in list
    -self = LinkedList()
        -clears self LinkedList to hold new total
    -self.listAdd(totalholder,productholder,1,0)
        -uses listAdd function to add running total to current product
    -totalholder = LinkedList(self.toStringSlist())
        -stores running total for next call
    -temp = LinkedList()
        -produces empty LinkedList so next productholder is empty
    -return self.listMult(list1,list2,temp,totalholder, step1+1,step2)
        -recursion call step one more digit left in list 1
    -elif step1 >= list1.count:
        -final recursion call for current digit in list2
    -step1 = 1
        -resets step1 for next digit from list2
    -return self.listMult(list1,list2,temp,totalholder,step1,step2+1)
        -returns to multiplying one digit left in list2 by all of list1
    -elif step2 >= list2.count:
        -final recursive call for last digit of smaller list
    -elif step1 >= list1.count:
        -final digit multiplication and addition to total
    -totalholder.printlist(totalholder.head)
        -prints result of multiplication
#######################################################################################################################################################################

def toStringSlist(self,node = None,strin ="") - is used if the linked list contains strings in the nodes rather than objects
def toStringdefaultSlist(self,node,strin) - second part to toStringSlist() / was created so that recursion could be performed with default parameters
#######################################################################################################################################################################

class digits - object that stores each digit as a place in an array
#######################################################################################################################################################################
def __init__(self,strin) - if given a string then it initalizes with that string contained and adds any leading zeros neccessary
def setnumber(self,strin,i=None) - sets the data contained in the object given a string of the data
def cusion(self,i=0) - adds in zeros where a number is not defined in the array
def __repr__(self) - adds in zeros where a number is not defined in the array
def __add__(self, other) - if the object is called by its self then it will output the number that was given
def getnum(self,i=0)  - returns a string of the number in the array
def toString(self, strin ="",i=0) - returns the number stored in the array but as a string
#######################################################################################################################################################################

with open(inputfile) as inputfile: - handles file input and loops through file    











