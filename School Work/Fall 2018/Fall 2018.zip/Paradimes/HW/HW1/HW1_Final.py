# -*- coding: utf-8 -*-
import sys

sys.setrecursionlimit(3250)
inputfile = "case1.txt"
numdigits = 1

def setvals():
    arr = LinkedList()
    findsymindex(sys.argv[1],arr)
    #print("The sym list contains : ")
    #arr.printlist(arr.head)

    global inputfile
    global numdigits

    if(len(sys.argv) > 1):
        if(findparam(sys.argv[1]) == "input"):
            inputfile = findparam((sys.argv[1])[int(arr.getindex(arr.head,0))+1:])
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
	
        if(findparam((sys.argv[1])[int(arr.getindex(arr.head,1))+1:]) == "digitsPerNode"):
            numdigits = int(findparam(sys.argv[1][int(arr.getindex(arr.head,2))+1:]))
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
        
        if(numdigits <=0):
            print("digits per node cant be negative!")
            sys.exit(-2)


def findsymindex(argstr,llist, i=0):
    if(len(argstr) <= 0):
        return llist
    elif(argstr[0] == "=" or argstr[0] == ";"):
        llist.append(i)
        return findsymindex(argstr[1:],llist,i+1)
    else:
        return findsymindex(argstr[1:],llist,i+1)

def findparam(arg):
    if(len(arg) <= 0):
        return ""
    elif(arg[0] == "=" or arg[0] == ";"):
        return ""
    else:
        return arg[0] + findparam(arg[1:])

def createnum(a): ## returns a string of a number before encountering a symbol or reaches the end
    if (len(a) <= 0 or a[0] == "+" or a[0] == "*"):
        return ""
    elif(a[0] == " "):
        return str(createnum(a[1:]))
    elif(a[0].isdigit()):
        return a[0] + str(createnum(a[1:]))
    else:
        return ""

def countstr(s):
    return len(s)

def printsameline(strin):
    sys.stdout.write(strin)
    sys.stdout.flush()
    
def removeleading(strin):
    if(strin == ""):
        return""
    return str(int(strin))

def printsym(i):
    if(i==1):
        printsameline("*")
    elif(i==2):
        printsameline("+")
    else:
        printsameline("?")
    
def findsym(a): ##returns the index of the first non digit occurence
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return 1+findsym(a[1:])
    elif(a[0] == "*" or a[0] == "+"):
        return 0
    else:
        print("ERROR unknown symbol")
        return -1
        
def checksym(a): ## returns a 1 if string contains a * or a 2 if + and -1 otherwise
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return checksym(a[1:])
    elif(a[0] == "*"):
        return 1
    elif(a[0] == "+"):
        return 2
    else:
        print("ERROR unknown symbol")
        return -1
    
def createresult(inputstr): ## creates the proper string to output
    sym = checksym(inputstr)
    if(sym == 1):
        
        return "*"
    elif(sym == 2):
        
        return "+"
    else:
        print("Error invalid symbol")
        sys.exit(-1)

class Node:
    def __init__(self, data=None, prev=None, next=None):
        self.data = data
        self.prev = prev
        self.next = next

    def __repr__(self):
        return repr(self.data)
    
    def __add__(self, other):
        return self.data + other.data
    #def __mul__(self, other):
        #return self.data * other.data
    def toString(self):
        return self.data.toString()


class LinkedList:
    
    def __init__(self, strin = ""):
        if strin is not "":
            self.head = None
            self.tail = None
            self.count = 0;
            self.makelistdigits(strin)
            
        else:
            self.head = None
            self.tail = None
            self.count = 0;
            
    def __repr__(self):
        def printlist(node):
            if(node.next == None):
                return node.data
            else:
                return node.data + printlist(node.next)
        
        cur = self.head
        return printlist(cur)
        

    def prepend(self, data):
        new_head = Node(data=data, next=self.head)
        if self.head:
            self.head.prev = new_head
        self.head = new_head
        self.count = self.count+1

    def append(self, data):
        def endnode(node): ##returns node at the end
            if(node.next == None):
                #print("found Node")
                return node
            else:
                #print(str(node.next))
                #print("Finding node.")
                return endnode(node.next)
                
        if not self.head:
            self.head = Node(data=data)
            self.count = self.count +1
            #print("Made head: "+str(self.head))
            return
        
        curr = self.head
        curr = endnode(curr)
        curr.next = Node(data=data, prev=curr)
        #print("Made node: "+str(curr.next))
        self.count = self.count +1
    
    def getindex(self,current, index , i = 0):
        if(current == None):
            return "-1"
        elif(index == i):
            return current.data
        else:
            return self.getindex(current.next, index ,i=i+1)
    
    def printlist(self,node = None):
        
        if node is None:
            self.Plistdefault(self.head)
        else:
            self.Plistdefault(node)
        
    def Plistdefault(self,node):
            if(node == None):
                return
            else:
                printsameline(str(node.data))#print(node)
                self.Plistdefault(node.next)
                
    def toString(self,node = None,strin =""):
        if node is None:
            return self.toStringdefault(self.head,strin)
        else:
            return self.toStringdefault(node,strin)
            
    def toStringdefault(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + node.data.toString()
                return self.toStringdefault(node.next,strin)
        
    def makelistdigits(self,strin):
        if(len(strin) <= numdigits):
            self.prepend(digits(strin))
        else:
            self.prepend(digits(strin[len(strin)-(numdigits):]))
            self.makelistdigits(strin[:-numdigits])
            
    def toStringSlist(self,node = None,strin =""):
        if node is None:
            return self.toStringdefaultSlist(self.head,strin)
        else:
            return self.toStringdefaultSlist(node,strin)
            
    def toStringdefaultSlist(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + str(node.data)
                return self.toStringdefaultSlist(node.next,strin)               
            
    def listAdd(self, list1, list2, step, carry): #Takes two LinkedLists and adds them from end node to beginning node and returns the result
        if list1 is None:
            return list2
        elif list2 is None:
            return list1
        elif step > list1.count and step <= list2.count:
            result = int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
            if len(str(result)) > numdigits:
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step <= list1.count and step > list2.count:
            result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + carry
            if len(str(result)) > numdigits:
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step > list1.count and step > list2.count:
            if carry == 1:
                self.prepend("1")
                return
            else:
                return
        result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
        if len(str(result)) > numdigits:
            self.prepend(result%10**numdigits)
            carry = 1
            return self.listAdd(list1,list2,step+1, carry)
        else:
            self.prepend(result)
            carry = 0
            return self.listAdd(list1,list2,step+1, carry)
    
    #takes two LinkedLists and multiplies them from end to beginning
    def listMult(self, list1, list2,productholder,totalholder,step1,step2):
        if list1 is None or list2 is None:
            print("Error, incorrect input")
        
        #stores string result of last digit of each number from right to left
        res1 = list1.getindex(list1.head,list1.count - step1,0).toString()
        res2 = list2.getindex(list2.head,list2.count - step2,0).toString()
        if list1.count == 1 or list2.count == 1: #handles event where one number is a single digit
            if list1.count > 1 and list2.count == 1: #steps through multiplying if one number is still larger than 1 digit size
                if step1 < list1.count: #steps through up to the second of a number, multiplies each digit by the other number and adds to totalholder
                    product = (int(res1) *10**(step1-1)) * int(res2)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    temp = LinkedList()
                    return self.listMult(list1,list2,temp,totalholder, step1+1,step2)
                elif step1 >= list1.count: #final call once last digit is reached and returns result
                    product = (int(res1) *10**(step1-1)) * int(res2)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    totalholder.printlist(totalholder.head)
                    return
            elif list1.count == 1 and list2.count > 1:
                if step2 < list2.count:
                    product = (int(res2) *10**(step2-1)) * int(res1)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    temp = LinkedList()
                    return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                    product = (int(res2) *10**(step2-1)) * int(res1)
                    productholder = LinkedList(str(product))
                    self = LinkedList()
                    self.listAdd(totalholder,productholder,1,0)
                    totalholder = LinkedList(self.toStringSlist())
                    totalholder.printlist(totalholder.head)
                    return
            elif list1.count == 1 and list2.count == 1: #if both numbers are 1 digit length, simply multiplies and returns
                product = int(res1) * int(res2)
                self.append(str(product))
                return
        elif list1.count >= list2.count: #executes multiplication for when list1 is longer or equal to list2
            if step2 < list2.count: #steps through the smaller list's digits from right to left up to the second to last digit
                if step1 < list1.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1)) #multiplies digits from right to left in list1 by list2 based on step in recursion
                        productholder = LinkedList(str(product)) #stores product of digits in list
                        self = LinkedList() #clears self LinkedList to hold new total
                        self.listAdd(totalholder,productholder,1,0) #uses listAdd function to add running total to current product
                        totalholder = LinkedList(self.toStringSlist()) #stores running total for next call
                        temp = LinkedList() #produces empty LinkedList so next productholder is empty
                        return self.listMult(list1,list2,temp,totalholder, step1+1,step2) #recursion call step one more digit left in list 1
                elif step1 >= list1.count: #final recursion call for current digit in list2
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        step1 = 1 #resets step1 for next digit from list2
                        return self.listMult(list1,list2,temp,totalholder,step1,step2+1) #returns to multiplying one digit left in list2 by all of list1
            elif step2 >= list2.count: #final recursive call for last digit of smaller list
                if step1 < list1.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1+1,step2)
                elif step1 >= list1.count: #final digit multiplication and addition to total
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        totalholder.printlist(totalholder.head)
                        return
        elif list1.count <= list2.count: #executes multiplication for when list2 is longer or equal to list1
            if step1 < list1.count:
                if step2 < list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        step2 = 1
                        return self.listMult(list1,list2,temp,totalholder,step1+1,step2)
            elif step1 >= list1.count:
                if step2 < list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        temp = LinkedList()
                        return self.listMult(list1,list2,temp,totalholder, step1,step2+1)
                elif step2 >= list2.count:
                        product = (int(res1) *10**(step1-1)) * (int(res2) *10**(step2-1))
                        productholder = LinkedList(str(product))
                        self = LinkedList()
                        self.listAdd(totalholder,productholder,1,0)
                        totalholder = LinkedList(self.toStringSlist())
                        totalholder.printlist(totalholder.head)
                        return


            
class digits:
    def __init__(self,strin):
        global numdigits
        self.arr = ["0"]*numdigits
        
        if(len(strin) == numdigits):
            self.setnumber(strin)
            self.cusion()
            
        elif(len(strin) > numdigits):
            print("Error Wrong sized string for digit object\t size of string given was: "+ str(len(strin)) + " Needs to be: "+ str(numdigits))
            
        else:
            self.setnumber(strin)
            self.cusion()
            
    def setnumber(self,strin,i=None):
        
        if i is None:
            if(len(strin)>0 and not strin ==""):
                return self.setnumber(strin,numdigits-1)
            else:
                return
        
        if(not len(strin) <= 0):
            self.arr[i] = strin[len(strin)-1]
            self.setnumber(strin[:-1],i-1)
            
    def cusion(self,i=0):
        if i is None:
            return self.setnumber(numdigits-1)
        
        if(i < 0):
            return
        elif(self.arr[i] == None or self.arr[i] == ""):
            self.arr[i] = "0"
            return self.cusion(i-1)
        
            
    def __repr__(self):
        return self.getnum()
    
    def __add__(self, other):
        return int(self.getnum()) + int(other.getnum())
    
    def getnum(self,i=0):       
        if(i<0):
            return -1
        elif(i>=numdigits-1):
            return self.arr[i]
        else:
            return self.arr[i] + self.getnum(i+1)
        
    def toString(self, strin ="",i=0):
        if (numdigits == i):
            return ""
        else:
            return self.arr[i] + self.toString(strin,i+1)
    
def isblank(strin):
    printsameline(strin)
    if strin and strin.strip():
        return True
    return False
        
with open(inputfile) as inputfile:
    for line in inputfile:
        num1 = createnum(line)
        num2 = createnum(line[(findsym(line)+1):])
        if(not num1 == "" and not num2 == ""):
    
            #runcode
            num1l = LinkedList(num1)
            num2l = LinkedList(num2)
            
            sign = checksym(line)
            
            if(sign == 1):
                printsameline(removeleading(num1l.toString()))
                printsym(sign)
                printsameline(removeleading(num2l.toString()))
                printsameline("=")
                
                productholder = LinkedList()
                totalholder = LinkedList("0")
                results = LinkedList()
                results.listMult(LinkedList(num1l.toString()),LinkedList(num2l.toString()),productholder,totalholder,1,1)
                print(results.toStringSlist())
                ##print(result)
                
            elif(sign == 2):
                printsameline(removeleading(num1l.toString()))
                printsym(sign)
                printsameline(removeleading(num2l.toString()))
                printsameline("=")
                
                results = LinkedList()
                results.listAdd(LinkedList(num1l.toString()),LinkedList(num2l.toString()),1,0)
                print(results.toStringSlist())
                
                ##print(result)
            else:
                print("Invalid Sign")
            
        else:
            print("Error one of the numbers is not valid")