# -*- coding: utf-8 -*-
import sys

inputfile = ""
numdigits = 1

def setvals():
    
    #print("The sym list contains : ")
    #arr.printlist(arr.head)

    global inputfile
    global numdigits

    if(len(sys.argv) > 1):
        arr = LinkedList()
        findsymindex(sys.argv[1],arr)
        if(findparam(sys.argv[1]) == "input"):
            inputfile = findparam((sys.argv[1])[int(arr.getindex(arr.head,0))+1:])
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
	
        if(findparam((sys.argv[1])[int(arr.getindex(arr.head,1))+1:]) == "digitsPerNode"):
            numdigits = int(findparam(sys.argv[1][int(arr.getindex(arr.head,2))+1:]))
        else:
            print("Error format is: input=<filename>;digitsPerNode=<number>")
        
        if(numdigits <=0):
            print("digits per node cant be negative!")
            sys.exit(-2)


def findsymindex(argstr,llist, i=0):
    if(len(argstr) <= 0):
        return llist
    elif(argstr[0] == "=" or argstr[0] == ";"):
        llist.append(i)
        return findsymindex(argstr[1:],llist,i+1)
    else:
        return findsymindex(argstr[1:],llist,i+1)

def findparam(arg):
    if(len(arg) <= 0):
        return ""
    elif(arg[0] == "=" or arg[0] == ";"):
        return ""
    else:
        return arg[0] + findparam(arg[1:])

def createnum(a): ## returns a string of a number before encountering a symbol or reaches the end
    if (len(a) <= 0 or a[0] == "+" or a[0] == "*"):
        return ""
    elif(a[0] == " "):
        return str(createnum(a[1:]))
    elif(a[0].isdigit()):
        return a[0] + str(createnum(a[1:]))
    else:
        return ""

def countstr(s):
    return len(s)

def printsameline(strin):
    sys.stdout.write(strin)
    sys.stdout.flush()
    
def removeleading(strin):
    if(strin == ""):
        return""
    return str(int(strin))

def printsym(i):
    if(i==1):
        printsameline("*")
    elif(i==2):
        printsameline("+")
    else:
        printsameline("?")
    
def findsym(a): ##returns the index of the first non digit occurence
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return 1+findsym(a[1:])
    elif(a[0] == "*" or a[0] == "+"):
        return 0
    else:
        print("ERROR unknown symbol")
        return -1
        
def checksym(a): ## returns a 1 if string contains a * or a 2 if + and -1 otherwise
    if (len(a) <= 0):
        return 0
    elif(a[0].isdigit() or a[0] == " "):
        return checksym(a[1:])
    elif(a[0] == "*"):
        return 1
    elif(a[0] == "+"):
        return 2
    else:
        print("ERROR unknown symbol")
        return -1
    
def createresult(inputstr): ## creates the proper string to output
    sym = checksym(inputstr)
    if(sym == 1):
        
        return "*"
    elif(sym == 2):
        
        return "+"
    else:
        print("Error invalid symbol")
        sys.exit(-1)

class Node:
    def __init__(self, data=None, prev=None, next=None):
        self.data = data
        self.prev = prev
        self.next = next

    def __repr__(self):
        return repr(self.data)
    
    def __add__(self, other):
        return self.data + other.data
    #def __mul__(self, other):
        #return self.data * other.data
    def toString(self):
        return self.data.toString()


class LinkedList:
    
    def __init__(self, strin = ""):
        if strin is not "":
            self.head = None
            self.tail = None
            self.count = 0;
            self.makelistdigits(strin)
            
        else:
            self.head = None
            self.tail = None
            self.count = 0;
            
    def __repr__(self):
        def printlist(node):
            if(node.next == None):
                return node.data
            else:
                return node.data + printlist(node.next)
        
        cur = self.head
        return printlist(cur)
        

    def prepend(self, data):
        new_head = Node(data=data, next=self.head)
        if self.head:
            self.head.prev = new_head
        self.head = new_head
        self.count = self.count+1

    def append(self, data):
        def endnode(node): ##returns node at the end
            if(node.next == None):
                #print("found Node")
                return node
            else:
                #print(str(node.next))
                #print("Finding node.")
                return endnode(node.next)
                
        if not self.head:
            self.head = Node(data=data)
            self.count = self.count +1
            #print("Made head: "+str(self.head))
            return
        
        curr = self.head
        curr = endnode(curr)
        curr.next = Node(data=data, prev=curr)
        #print("Made node: "+str(curr.next))
        self.count = self.count +1
    
    def getindex(self,current, index , i = 0):
        if(current == None):
            return "-1"
        elif(index == i):
            return current.data
        else:
            return self.getindex(current.next, index ,i=i+1)
    
    def printlist(self,node = None):
        
        if node is None:
            self.Plistdefault(self.head)
        else:
            self.Plistdefault(node)
        
    def Plistdefault(self,node):
            if(node == None):
                return
            else:
                printsameline(str(node.data))#print(node)
                self.Plistdefault(node.next)
                
    def toString(self,node = None,strin =""):
        if node is None:
            return self.toStringdefault(self.head,strin)
        else:
            return self.toStringdefault(node,strin)
            
    def toStringdefault(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + node.data.toString()
                return self.toStringdefault(node.next,strin)
        
    def makelistdigits(self,strin):
        if(len(strin) <= numdigits):
            self.prepend(digits(strin))
        else:
            self.prepend(digits(strin[len(strin)-(numdigits):]))
            self.makelistdigits(strin[:-numdigits])
            
    def listAdd(self, list1, list2, step, carry): #Takes two LinkedLists and adds them from end node to beginning node and returns the result
        if list1 is None:
            return list2
        elif list2 is None:
            return list1
        elif step > list1.count and step <= list2.count:
            result = int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
            if len(str(result)) > numdigits:
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step <= list1.count and step > list2.count:
            result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + carry
            if len(str(result)) > numdigits:
                self.prepend(result%10**numdigits)
                carry = 1
                return self.listAdd(list1,list2,step+1, carry)
            else:
                self.prepend(result)
                carry = 0
                return self.listAdd(list1,list2,step+1, carry)
        elif step > list1.count and step > list2.count:
            return
        result = int(list1.getindex(list1.head,list1.count - step,0).toString()) + int(list2.getindex(list2.head,list2.count - step,0).toString()) + carry
        if len(str(result)) > numdigits:
            self.prepend(result%10**numdigits)
            carry = 1
            return self.listAdd(list1,list2,step+1, carry)
        else:
            self.prepend(result)
            carry = 0
            return self.listAdd(list1,list2,step+1, carry)
    
    def toStringSlist(self,node = None,strin =""):
        if node is None:
            return self.toStringdefaultSlist(self.head,strin)
        else:
            return self.toStringdefaultSlist(node,strin)
            
    def toStringdefaultSlist(self,node,strin):
            if(node == None):
                return strin
            else:
                strin = strin + str(node.data)
                return self.toStringdefaultSlist(node.next,strin)
        
        
class digits:
    def __init__(self,strin):
        global numdigits
        self.arr = ["0"]*numdigits
        
        if(len(strin) == numdigits):
            self.setnumber(strin)
            self.cusion()
            
        elif(len(strin) > numdigits):
            print("Error Wrong sized string for digit object\t size of string given was: "+ str(len(strin)) + " Needs to be: "+ str(numdigits))
            
        else:
            self.setnumber(strin)
            self.cusion()
            
    def setnumber(self,strin,i=None):
        
        if i is None:
            if(len(strin)>0 and not strin ==""):
                return self.setnumber(strin,numdigits-1)
            else:
                return
        
        if(not len(strin) <= 0):
            self.arr[i] = strin[len(strin)-1]
            self.setnumber(strin[:-1],i-1)
            
    def cusion(self,i=0):
        if i is None:
            return self.setnumber(numdigits-1)
        
        if(i < 0):
            return
        elif(self.arr[i] == None or self.arr[i] == ""):
            self.arr[i] = "0"
            return self.cusion(i-1)
        
            
    def __repr__(self):
        return self.getnum()
    
    def __add__(self, other):
        return int(self.getnum()) + int(other.getnum())
    
    def getnum(self,i=0):       
        if(i<0):
            return -1
        elif(i>=numdigits-1):
            return self.arr[i]
        else:
            return self.arr[i] + self.getnum(i+1)
        
    def toString(self, strin ="",i=0):
        if (numdigits == i):
            return ""
        else:
            return self.arr[i] + self.toString(strin,i+1)
    
def isblank(strin):
    printsameline(strin)
    if strin and strin.strip():
        return True
    return False

def multLists(self,list1,list2, i =-10,j=-10,k=-10):
    if(i == -10 or j==-10 or k ==-10):
        if(list1.count > list2.count):
            return self.multilists(list1,list2,list1.count,list2.count,numdigits)
        else:
            return self.multilists(list2,list1,list2.count,list1.count,numdigits)
    else:
        if(list1.count > list2.count):
            return self.multiLists(list1,list2,i,j,k)
        else:
            return self.multiLists(list2,list1,j,i,k)
    
def multilist(self,list1,list2,i,j,k,final = None):
    if(final == None):
        holder = LinkedList()
        return self.multilist(list1,list2,i,j,k,holder)
    
    if(i==-1 or j == -1):
        return final
    
    if(k == -1): #use listAdd in here
        return self.multilist(list1,list2,i,j-1,numdigits-1,final)
    else:#use listAdd in here
        num = getnumfromstr(list2.toString(),j)
        return multsingle(list1,num,i,j,k-1)
    
    
def multsingledefault(list1,num,carry=0,i=-10,finlist = None):
    if(finlist == None or i == -10):
        tempparam = LinkedList()
        multsingle(list1,num,tempparam,carry,list1.count-1)
        
    else:
        multsingle(list1,num,finlist,carry,i)
        

def multsingle(list1,num,finlist,carry=0,i=-10):
    
    if(i == -1):
        if(carry > 0):
            finlist.prepend(digits(str(carry)))
        print(finlist.toString())
        return finlist
    else:
        temp = (num * int(str(list1.getindex(list1.head,i))))+carry
        carry = str(temp)[:-numdigits]
        if(carry == ""):
            carry=0
        else:
            carry= int(carry)
        finlist.prepend(digits(str(temp)[(len(str(temp))-numdigits):]))
        return multsingle(list1,num,finlist,carry,i-1)
        
        
        
    
def getnumfromstr(self,strin,index=0,i=0):
    if(index <0 or i<0):
        return
    elif(index>=i):
        if(i==index):
            return int(strin[i])
        else:
            return getnumfromstr(strin,index,i+1)
    else:
        return


setvals()
#print(inputfile)
#print(numdigits)

        
lista = LinkedList("1234")
number = 2

print(multsingledefault(lista,number))
        