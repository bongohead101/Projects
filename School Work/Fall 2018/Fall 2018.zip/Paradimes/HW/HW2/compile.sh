echo "Removing previous build.."
rm -rf a.out
echo "Building.."
g++ -std=c++11 -pthread -fpermissive main.cpp
# clear all
echo "Starting Experiments"
echo "STARTING INPUT case1.txt"
./a.out case1.txt 1>out1.txt

echo "STARTING INPUT case2.txt"
./a.out case2.txt 1>out2.txt

echo "STARTING INPUT case3.txt"
./a.out case3.txt 1>out3.txt

echo "STARTING INPUT case4.txt"
./a.out case4.txt 1>out4.txt

echo "End of Experimets"

