#include <iostream>
#include <list>
using namespace std;

template <class T>
class pair{
	public:
		string key;
		T data;

		pair();
		pair(string a,T b){key =a; data = T;}
		void setkey(string a){key =a;}
		void setdata(T a){data = a;}
		string getkey(){return key;}
		T getdata(){return data;}
	
}

void printlist(list<string> l){
	for(auto it = l.begin();it != l.end();++it){
		cout << *it <<endl;
	}
	cout << endl;

}
