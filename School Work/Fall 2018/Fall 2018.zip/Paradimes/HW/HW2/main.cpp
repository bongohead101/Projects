#include <fstream>
#include <string>
#include <iostream>
#include "statement.h"
using namespace std;


int main(int argc,char *argv[]){

	fstream inputfile;
	inputfile.open(argv[1],ios::in);

	if(!inputfile.is_open()){
		cerr << "Error opening file!" << endl;
		exit(-1);
	}

	while(!inputfile.eof()){
		string temp;
		getline(inputfile,temp);
		cout <<temp<<endl;

	}


	list<string> reservewords;



	statement test("abc = 1 + too");
	cout << test.getline()<<endl;
	cout << "Leading: "<< test.countleading()<<endl;
	cout << "First sym at: "<<test.findfirstsym()<<endl;
	
	cout << "Variable list contains: ";
	printlist(test.variables);	

	return 0;
}

