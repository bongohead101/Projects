#include <iostream>
#include "funs.h"
using namespace std;

class statement{
	public:
		statement();
		statement(string);
		string line;
		int leadingspaces;
		int action;
		list<string> variables;

		
		void setline(string);
		string getline();
		int countleading();
		int findfirstsym();
		void createvarlist();
};



statement::statement(){
	line = "";
	leadingspaces = 0;
	action = -1;
}

statement::statement(string a){
	line = a;
	leadingspaces = countleading();
	createvarlist();
}

void statement::setline(string a){
	line = a;
}

string statement::getline(){
	return line;
}

int statement::countleading(){
	int count =0;
	for(int i =0;i < line.size();i++){
		if(line[i]==' '){
			count++;	
		}else{
			break;
		}
	}
	
	return count;
}

int statement::findfirstsym(){

	for(int i =0;i < line.size();i++){
                if(!(isalpha(line[i]) !=0) && !(isdigit(line[i]) !=0) && line[i] != ' '){
			cout<<"char is:"<<line[i] << "\nisalpha is: "<< isalpha(line[i])<<" isdigit is: "<<isdigit(line[i])<<endl;
			return i;
              	}
        }
	return -1;

}


void statement::createvarlist(){
	string temp="";
	for(int i =0;i < line.size();i++){
		
                if(isalpha(line[i]) !=0 || isdigit(line[i]) !=0){
                        temp = temp + line[i];
			if(i == (line.size() -1) && temp.size() >=1){
                        	variables.push_back(temp);
                	}        
                }else if((line[i] == ' ' || (((int)line[i])>=33 && (int)line[i]<=47) || (((int)line[i])>=58 && (int)line[i]<=64) || (((int)line[i])>=91 && (int)line[i]<=96) || (((int)line[i])>=123 && (int)line[i]<=126)) && temp.size() >=1){
			variables.push_back(temp);
			temp = "";
		}
		
        }	


}


