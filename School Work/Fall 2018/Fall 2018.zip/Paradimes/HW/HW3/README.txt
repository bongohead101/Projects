################################
#     Homework 2 COSC 4315     #
################################
Marc Cardenas 1597234

#partner dropped before starting assignment

The objective of this program was to not use mutation or loops to immitate lambda funtions.

Compile Instructions
################################################################################
#to run use python 3
ex: python3 infinitearithmetic "input=<filename>;digitsPerNode=<number>"

Limitations
################################################################################
-hits super high recursive limit for the multiplication
	-just used normal multiplication for test cases
	-implementation is still there just use smaller numbers for testing
	-implementation is on line 132
		-takes in 2 lists and adds it to itself a certain amount of times
		 therfore hits the recursion limit but it still works

