import sys

sys.setrecursionlimit(50000)

def getnumnodes():
    if(sys.argv[1] == ""):
        return -1
    return int((sys.argv[1])[((sys.argv[1])[sys.argv[1].index(";"):]).index("=")+sys.argv[1].index(";")+1:])
    
def getinputfilename():
    if(sys.argv[1]==""):
        return ""
    return sys.argv[1][sys.argv[1].index("=")+1:sys.argv[1].index(";")]

def hasfunction(s):#given a string
    if "add(" in s:
        return True
    elif "multiply(" in s:
        return True
    else:
        return False

def getfunction(s):
    if "add(" in s:
        return "add"
    elif "multiply(" in s:
        return "multiply"
    

class dummy:
    def __init__(self,d = 0):
        data = d
        
    def indexofcomma(self,strin = "",index =0,ignore = 0):
        if(index == len(strin)):
            return -1
        elif(strin[index] == "("):
            return self.indexofcomma(strin,index+1,ignore+1)
        elif(strin[index] == ")"):
            return self.indexofcomma(strin,index+1,ignore-1)
        elif(ignore == 0 and strin[index] == ","):
            #print("FOUND!:" + str(index))
            return index
        else:
            #print("Gone through else! Case unaccounted :" + strin[index])
            return self.indexofcomma(strin,index+1,ignore)
            

def getbeforecomma(s):#already accounts for origin function call & parenthesis
    y = dummy()
    return s[:y.indexofcomma(s)]

def getaftercomma(s): #already accounts for origin function call & parenthesis
    y= dummy()
    return s[y.indexofcomma(s)+1:]

def removelastchar(s):
    if(len(s)-1 < 1):
        print("String too smoll!")
        
    if(s[len(s)-1] == "\n"):
        return s[:-2]
    return s[:-1]

def removelastparen(a,index = -20):
    if(index == -20):
        return removelastparen(a,len(a)-1)
    
    if(a[index] == ")"):
        return a[:index]

def cleanstr(a,index=0,result=""):
    if(index>=len(a)):
        return result

    elif(a[index].isdigit()):
        return(a,index+1,result+a[index])
    
        

def formatstring(s):
    if(len(s)>0):
        if(s[len(s)-1] == "\n"):
            return s[:-1]
    return s

def getoriginfcall(s):
    if(s ==""):
        return""
    return s[:s.index("(")]

def getparam1(s):
    return getbeforecomma(s[s.index("(")+1:])
    
def getparam2(s):
    return getaftercomma(s[s.index("(")+1:])
    
def getparam2wp(s):
    #print(removelastchar(removelastchar(formatstring(getaftercomma(s[s.index("(")+1:])))))
    #return removelastchar(removelastchar(formatstring(getaftercomma(s[s.index("(")+1:]))))
    return removelastchar(getaftercomma(s[s.index("(")+1:]))

def evaluate(s):
    if(s == ""):
        return " invalid expression"
    
    if(hasfunction(getparam1(s))):
        #print("Param1:"+getparam1(s))
        param1 = int(evaluate(getparam1(s)))
    elif(getparam1(s)==""):
        return " invalid expression"
    else:
        param1 = int(getparam1(s))
    
    if(hasfunction(getparam2wp(s))):
        #print("Param2:"+getparam2wp(s))
        param2 = int(evaluate(getparam2wp(s)))
    elif(getparam2wp(s) == ""):
        return " invalid expression"
    else:
        #print(getparam2wp(s))
        param2 = int(getparam2wp(s))
        
    ##needs to be changed to origin statement
    if "add" in getoriginfcall(s): #"add(" in s:
        #print("add: Param1:" + str(param1)+" Param2:"+str(param2))
        return sprintlist(saddcontents(tolist(str(param1)),tolist(str(param2))))#str(param1+param2)
        
    elif "multiply" in getoriginfcall(s):#"multiply(" in s:
        #print("Mult: Param1:" + str(param1)+" Param2:"+str(param2))
        return str(param1*param2)
        #return sprintlist(smult(tolist(str(param1)),tolist(str(param2))))
        
        
###############################################################################
#file formatter end
###############################################################################

def slinsert(a , b): #lists in order of insertion used for non mutation
    return a+b

def printsameline(strin):
    sys.stdout.write(strin)
    sys.stdout.flush()

class node:
    def __init__(self, data=None):
        
        self.data = data
        #self.cusion()
        
    def __repr__(self):
        return repr(self.data)

    def __add__(self, other):
         return self.data + other.data

    def __mul__(self,other):
        return self.data * other.data
    
    def __sub__(self, other):
         return self.data - other.data
    
    def iszero(self):
        if(self.data == 0):
            return True
        return False

    #cusion everything after the first index at print time otherwise keep as int

def cushionnode(anode):
    sdata = str(anode.data)
    if(len(sdata)<getnumnodes()):
        return ("0"*(getnumnodes()-len(sdata)))+sdata
        
    return sdata

def printlist(a,index =0):
    if(index<len(a)):
        if(index == 0):
            printsameline(str(a[index]))
        else:
            printsameline(cushionnode(a[index]))
        
        printlist(a,index+1)

def sprintlist(a,index =0,strin= ""):
    if(index<len(a)):
        if(index == 0):
            temp = strin + str(a[index])
        else:
            temp = strin + cushionnode(a[index])
            
        return sprintlist(a,index+1,temp)
    else:
        return strin




def decrementlist(a,index = -20):
    if(index == -20):
        return decrementlist(a,len(a)-1)
    
    if(index == -1):
        return []
    
    elif(a[index].iszero()):
        #if node already 0
        return decrementlist(a,index-1)
    elif(len(a)==1):
        temp = [node(a[index] - node(1))]
        return temp
        
    else:
        if(index < len(a)-1):
            temp = [node(a[index] - node(1))]
            #print("changed node:"+str(index)+" to "+str(slinsert(a[:index],temp)))
            #print("adding the new carried item:"+str(tolist(str((10**getnumnodes())-1)*((len(a)-1)-index))))
            #print("had to borrow so list is now:"+ str(saddcontents(slinsert(a[:index],temp), tolist(str((10**getnumnodes())-1)*((len(a)-1)-index)))))
            return slinsert(slinsert(a[:index],temp), tolist(str((10**getnumnodes())-1)*((len(a)-1)-index)))
        else:
            temp = [node(a[index] - node(1))]
            return slinsert(a[:index],temp)

#number to list of nodes
def tolist(a,final = []):
    if(len(a)-1 < getnumnodes()):
        #push the rest to front
        temp = slinsert([node(int(a))],final)
        return temp
    else:
        temp = slinsert([node(int(a[len(a)-getnumnodes():]))], final)
        return tolist(a[:len(a)-getnumnodes()],temp)

def saddcontents(a,b):
    def addition(a,b,final=[],index=-20,indexb=-2,carry=0):
        if(index == -20):
            #if(len(b)>len(a)):
             #   return addition(b,a,final,len(b)-1,len(a)-1,carry)
            return addition(a,b,final,len(a)-1,len(b)-1,carry)

        #print("index is:"+ str(index))
        #print("indexb is:" + str(indexb))
        #print("final is:"+str(final))
        
        if(index == -1 and indexb ==-1):
            if(carry > 0):
                return slinsert([node(carry)],final)
            return final
        
        elif((index == -1 and indexb != -1) or (indexb == -1 and index != -1)):#(index<0 and index!=-1 and indexb>=0)or (indexb<0 and indexb != -1 and index >=0)
            # add the rest of the bigger and carry
           
            if(len(a) > len(b)):
                
                #if a is bigger after adding the carry copy what is left
                temp = slinsert([node(a[index]+node(carry))],final)
                
                if(carry ==1):
                    return addition(a,b,temp,index-1,indexb,0)
                else:
                    return addition(a,b,temp,index-1,indexb,carry)
                
                
            else:
                
                #if b is bigger after adding the carry copy what is left
                temp = slinsert([node(b[indexb]+node(carry))],final)
                
                if(carry ==1):
                    return addition(a,b,temp,index,indexb-1,0)
                else:
                    return addition(a,b,temp,index,indexb-1,carry)
            
        else:
            #print("index:"+str(index))
            #print("indexb:"+ str(indexb))
            result = (a[index]+b[indexb]) +carry
            
            #print("carry is:"+str(carry))
            #print("result is: "+ str(result))
            #print("remainder is: "+ str(int(result/((10**getnumnodes())-1))))
            
            if(result/((10**getnumnodes())-1) >1):
                temp = slinsert([node(result-((10**getnumnodes())))],final)
                return addition(a,b,temp,index-1,indexb-1,1)
            else:
                temp = slinsert([node(result)],final)
                return addition(a,b,temp,index-1,indexb-1,0)
            
    return addition(a,b)
            
def liszero(a,index=0):
    if(len(a) <= index):
        return True
    elif(a[index].iszero()):
        return liszero(a,index+1)
    else:
        return False

def smult(original, times, result=[]):
    if result == []:
        if(liszero(times)):
            return smult(original,times,times)
        
        if(len(original)>len(times)):
            return smult(original, decrementlist(times), original)
        else:
            return smult(times, decrementlist(original), times)
    
    #print(decrementlist(times))
    
    if times == [] or liszero(times):
        return result
    else:
        return smult(original, decrementlist(times),saddcontents(result,original))

###############################################################################
#file reader
###############################################################################

printlist(smult(tolist("12345"),tolist("22")))
print("")


with open(getinputfilename()) as inputfile:
    for line in inputfile:
        if(line != ""):
            #print("Line is:"+ line)
            print(formatstring(line)+ "=" + evaluate(line))

