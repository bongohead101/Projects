#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(int argc,char* argv[])
{
	//exit program if given comand line arguments
	if(argc > 1){
		cerr << "Error This Program does not currently accept arguments other than input files." << endl;
		exit(1);
	}else{
		//creating file stream
		fstream file;
		file.open("input.txt", ios::in);
		
		// stops program if unable to open input file
			if(!file.is_open()){
				cerr << "Error opening input.txt file." << endl;
				exit(2);
			}

		//checking dimensions of matrix
		string line;
		char* charline;
		while(!file.eof())
		{
			getline(file, line);
			strcpy(charline, line.c_str());
			if(line != "" && (line[0] != '#' || line[0] != '//')) {
				for(int i =0; i;i++){
					if(charline[i] != NULL){
						cerr << charline[i]<< endl;
					}else{
						break;
					}

				}
			}

		}


		//creating a double array matrix
			double** matrix = new double*[];


		return 0;
	}
}