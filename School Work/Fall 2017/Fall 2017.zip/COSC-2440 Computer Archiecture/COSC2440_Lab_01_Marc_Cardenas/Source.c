#include<stdio.h>
#include<math.h>

int main()
{
	int number_1 = 10;
	int number_2 = 20;
	int number_3;
	
	number_1 = number_1 + number_2;
	number_3 = number_1 - number_2;
	
	return 0;
}