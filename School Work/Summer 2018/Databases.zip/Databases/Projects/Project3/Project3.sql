DROP TABLE DoesBusinessIn;
DROP TABLE Salesperson;
DROP TABLE Territory;
DROP TABLE OrderLine;
DROP TABLE OrderT;

DROP TABLE Customer;
DROP TABLE Product;
DROP TABLE ProductLine;
DROP TABLE PriceUpdate;

DROP VIEW ProductManager;
DROP VIEW ProductLineSales;
DROP VIEW TotalValueForProducts;
DROP VIEW DataForCustomer;
DROP VIEW CustomerByStatesShipment;
DROP VIEW PastPurchaseHistoryReport;
/*---------------------------------------------------------------------------------------------------------------------*/

CREATE TABLE Customer(CustomerID INTEGER PRIMARY KEY,
CustomerName CHAR(30),
CustomerAddress CHAR(30),
CustomerCity CHAR(15),
CustomerState CHAR(6),
CustomerPostalCode CHAR(13),
CustomerEmail CHAR(30),
CustomerUserName CHAR(20),
CustomerPassword CHAR(20));

CREATE TABLE ProductLine(ProductLineID INTEGER PRIMARY KEY, ProductLineName CHAR(30));

CREATE TABLE Product(ProductID INTEGER PRIMARY KEY,
ProductName CHAR(30),
ProductFinish CHAR(20),
ProductStandardPrice INTEGER,
ProductLineID INTEGER,
Photo CHAR(30),
FOREIGN KEY(ProductLineID) REFERENCES ProductLine);

CREATE TABLE Territory(TerritoryID INTEGER PRIMARY KEY,TerritoryName CHAR(15));

CREATE TABLE Salesperson(SalespersonID INTEGER PRIMARY KEY,
SalespersonName CHAR(15),
SalespersonPhone CHAR(11),
SalespersonEmail CHAR(30),
SalespersonUserName CHAR(20),
SalespersonPassword CHAR(20),
TerritoryID INTEGER,
FOREIGN KEY(TerritoryID) REFERENCES Territory);

CREATE TABLE DoesBusinessIn(CustomerID INTEGER,
TerritoryID INTEGER,
PRIMARY KEY(CustomerID,TerritoryID),
FOREIGN KEY(CustomerID) REFERENCES Customer,
FOREIGN KEY(TerritoryID) REFERENCES Territory);

CREATE TABLE OrderT(OrderID INTEGER PRIMARY KEY,
OrderDate CHAR(15),
CustomerID INTEGER,
FOREIGN KEY(CustomerID) REFERENCES Customer);

CREATE TABLE OrderLine(OrderID INTEGER,
ProductID INTEGER,
OrderedQuantity INTEGER,
SalePrice FLOAT,
PRIMARY KEY(OrderID,ProductID),
FOREIGN KEY(OrderID) REFERENCES OrderT,
FOREIGN KEY(ProductID) REFERENCES Product);

CREATE TABLE PriceUpdate(PriceUpdateID INTEGER,
DateChanged CHAR(12),
OldPrice FLOAT,
NewPrice FLOAT);

/*---------------------------------------------------------------------------------------------------------------------*/

INSERT INTO Customer
VALUES(1,'Contemporary Casuals', '1355 S Hines Blvd', 'Gainesville', 'FL', '32601-2871',null,null,null);
INSERT INTO Customer
VALUES(2,'Value Furnitures', '15145 S.W. 17th St.', 'Plano', 'TX', '75094-7734',null,null,null);
INSERT INTO Customer
VALUES(3,'Home Furnishings', '1900 Allard Ave', 'Albany', 'NY', '12209-1125',  'homefurnishings?@gmail.com', 'CUSTOMER1', 'CUSTOMER1#');
INSERT INTO Customer
VALUES(4,'Eastern Furniture', '1925 Beltline Rd.', 'Carteret', 'NJ', '07008-3188',null,null,null);
INSERT INTO Customer
VALUES(5,'Impressions', '5585 Westcott Ct.', 'Sacramento', 'CA', '94206-4056',null,null,null);
INSERT INTO Customer
VALUES(6,'Furniture Gallery', '325 Flatiron Dr.', 'Boulder', 'CO', '80514-4432',null,null,null);
INSERT INTO Customer
VALUES(7,'New Furniture', 'Palace Ave', 'Farmington', 'NM', null,null,null,null);
INSERT INTO Customer
VALUES(8,'Dunkins Furniture', '7700 Main St', 'Syracuse', 'NY', '31590',null,null,null);
INSERT INTO Customer
VALUES(9,'A Carpet', '434 Abe Dr', 'Rome', 'NY', '13440',null,null,null);
INSERT INTO Customer
VALUES(12,'Flanigan Furniture', 'Snow Flake Rd', 'Ft Walton Beach', 'FL', '32548',null,null,null);
INSERT INTO Customer
VALUES(13,'Ikards', '1011 S. Main St', 'Las Cruces', 'NM', '88001',null,null,null);
INSERT INTO Customer
VALUES(14,'Wild Bills', 'Four Horse Rd', 'Oak Brook', 'Il', '60522',null,null,null);
INSERT INTO Customer
VALUES(15,'Janet''s Collection', 'Janet Lane', 'Virginia Beach', 'VA', '10012',null,null,null);
INSERT INTO Customer
VALUES(16,'ABC Furniture Co.', '152 Geramino Drive', 'Rome', 'NY', '13440',null,null,null);

SELECT * FROM Customer;

INSERT INTO Productline VALUES(1, 'Cherry Tree');
INSERT INTO Productline VALUES(2, 'Scandinavia');
INSERT INTO Productline VALUES(3, 'Country Look');

SELECT * FROM ProductLine;

INSERT INTO Product
VALUES(1,'End Table', 'Cherry', 175, 1, 'Photo.jpg');/*HOW INSERT .JPG*/
INSERT INTO Product
VALUES(2,'Coffee Table', 'Natural Ash', 200, 2,null);
INSERT INTO Product
VALUES(3,'Computer Desk', 'Natural Ash', 375, 2,null);
INSERT INTO Product
VALUES(4,'Entertainment Center', 'Natural Maple', 650, 3,null);
INSERT INTO Product
VALUES(5,'Writers Desk', 'Cherry', 325, 1,null);
INSERT INTO Product
VALUES(6,'8-Drawer Desk', 'White Ash', 750, 2,null);
INSERT INTO Product
VALUES(7,'Dining Table', 'Natural Ash', 800, 2,null);
INSERT INTO Product
VALUES(8,'Computer Desk', 'Walnut', 250, 3,null);

SELECT * FROM Product;

INSERT INTO Territory
VALUES(1, 'SouthEast');
INSERT INTO Territory
VALUES(2, 'SouthWest');
INSERT INTO Territory
VALUES(3, 'NorthEast');
INSERT INTO Territory
VALUES(4, 'NorthWest');
INSERT INTO Territory
VALUES(5, 'Central');

SELECT * FROM Territory;

INSERT INTO Salesperson
VALUES(1,'Doug Henny', '8134445555', 'salesperson?@gmail.com', 'SALESPERSON', 'SALESPERSON#',1);
INSERT INTO Salesperson
VALUES(2,'Robert Lewis', '8139264006', null, null, null,2);
INSERT INTO Salesperson
VALUES(3,'William Strong', '5053821212', null, null, null,3);
INSERT INTO Salesperson
VALUES(4,'Julie Dawson', '4355346677', null, null, null,4);
INSERT INTO Salesperson
VALUES(5,'Jacob Winslow', '2238973498', null, null, null,5);

SELECT * FROM Salesperson;

INSERT INTO DoesBusinessIn VALUES(1,1);
INSERT INTO DoesBusinessIn VALUES(2,2);
INSERT INTO DoesBusinessIn VALUES(3,3);
INSERT INTO DoesBusinessIn VALUES(4,4);
INSERT INTO DoesBusinessIn VALUES(5,5);
INSERT INTO DoesBusinessIn VALUES(6,1);
INSERT INTO DoesBusinessIn VALUES(7,2);

SELECT * FROM DoesBusinessIn;

INSERT INTO OrderT VALUES(1001, '21/Aug/16', 1);
INSERT INTO OrderT VALUES(1002, '21/Jul/16', 8);
INSERT INTO OrderT VALUES(1003, '22/ Aug/16', 15);
INSERT INTO OrderT VALUES(1004, '22/Oct/16', 5);
INSERT INTO OrderT VALUES(1005, '24/Jul/16', 3);
INSERT INTO OrderT VALUES(1006, '24/Oct/16', 2);
INSERT INTO OrderT VALUES(1007, '27/ Aug/16', 5);
INSERT INTO OrderT VALUES(1008, '30/Oct/16', 12);
INSERT INTO OrderT VALUES(1009, '05/Nov/16', 4);
INSERT INTO OrderT VALUES(1010, '05/Nov/16', 1);

SELECT * FROM OrderT;

INSERT INTO OrderLine VALUES(1001, 1, 2,null);
INSERT INTO OrderLine VALUES(1001, 2, 2,null);
INSERT INTO OrderLine VALUES(1001, 4, 1,null);
INSERT INTO OrderLine VALUES(1002, 3, 5,null);
INSERT INTO OrderLine VALUES(1003, 3, 3,null);
INSERT INTO OrderLine VALUES(1004, 6, 2,null);
INSERT INTO OrderLine VALUES(1004, 8, 2,null);
INSERT INTO OrderLine VALUES(1005, 4, 4,null);
INSERT INTO OrderLine VALUES(1006, 4, 1,null);
INSERT INTO OrderLine VALUES(1006, 5, 2,null);
INSERT INTO OrderLine VALUES(1006, 7, 2,null);
INSERT INTO OrderLine VALUES(1007, 1, 3,null);
INSERT INTO OrderLine VALUES(1007, 2, 2,null);
INSERT INTO OrderLine VALUES(1008, 3, 3,null);
INSERT INTO OrderLine VALUES(1008, 8, 3,null);
INSERT INTO OrderLine VALUES(1009, 4, 2,null);
INSERT INTO OrderLine VALUES(1009, 7, 3,null);
INSERT INTO OrderLine VALUES(1010, 8, 10,null);

SELECT * FROM OrderLine;

/*---------------------------------------------------------------------------------------------------------------------*/

CREATE VIEW ProductManager(CID, CNAME, CZIP,PID,PNAME,PFINISH,PPRICE,PLINENAME,ONUMBER,OPLACEDDATE,OQUANTITY) AS
SELECT C.CustomerID,C.CustomerName,C.CustomerPostalCode,P.ProductID,P.ProductName,P.ProductFinish,P.ProductStandardPrice,PL.ProductLineName,OL.OrderID,O.OrderDate,OL.OrderedQuantity
FROM Customer C, Product P, ProductLine PL, OrderT O, OrderLine OL
WHERE C.CustomerID = O.CustomerID AND O.OrderID = OL.OrderID AND OL.ProductID = P.ProductID AND P.ProductLineID = PL.ProductLineID;

CREATE VIEW ProductLineSales(PRODUCT, TOTALSALES) AS
SELECT P.ProductName, OL.OrderedQuantity*P.ProductStandardPrice
FROM ProductLine PL, Product P, OrderLine OL
WHERE P.ProductLineID = PL.ProductLineID AND OL.ProductID = P.ProductID;

CREATE VIEW TotalValueForProducts(PRODUCT, TOTALSALES) AS
SELECT P.ProductName,SUM(OL.ORDEREDQUANTITY * P.ProductStandardPrice)
FROM ProductLine PL, Product P, OrderLine OL
WHERE P.ProductLineID = PL.ProductLineID AND OL.ProductID = P.ProductID 
GROUP BY P.ProductName;

CREATE VIEW DataForCustomer(PRODUCTS, PRICE)AS
SELECT DISTINCT(P.ProductName),P.ProductStandardPrice
FROM Product P, Customer C,Salesperson S,DoesBusinessIn DBI, OrderT O, OrderLine OL
WHERE DBI.TerritoryID = S.TerritoryID AND C. CustomerID = O.CustomerID AND OL.OrderID = O.OrderID AND OL.ProductID = P.ProductID;

CREATE VIEW CustomerByStatesShipment(STATE, NUMCUSTOMERS)AS
SELECT c.CustomerState, COUNT(*)
FROM Customer c
GROUP BY c.CustomerState;

CREATE VIEW PastPurchaseHistoryReport(ORDERDATE,QUANTITY,PRICE,PRODUCT) AS
SELECT O.OrderDate,OL.OrderedQuantity,OL.SalePrice,P.ProductName
FROM OrderT O, OrderLine OL,Product P,Customer C
WHERE C.CustomerID = O.CustomerID AND O.OrderID = OL.OrderID AND OL.ProductID = P.ProductID;

/*---------------------------------------------------------------------------------------------------------------------*/

/*Add column SalePrice to store updated prices from ProductLineSale Procedure*/
ALTER TABLE Product
    ADD SalePrice FLOAT;


DROP PROCEDURE ProductLineSale;

/*Create procedure named ProductLineSale*/
CREATE PROCEDURE ProductLineSale

    IS
        
    BEGIN

        UPDATE Product
        SET SalePrice = ProductStandardPrice * 0.90
        WHERE ProductStandardPrice >= 400;
    
        UPDATE Product
        SET SalePrice = ProductStandardPrice * 0.75
        WHERE ProductStandardPrice < 400;
        
    END;
    
/
    
EXECUTE ProductLineSale;


/*Drop and create table named PriceUpdates for Trigger use*/
DROP TABLE PriceUpdates;
CREATE TABLE PriceUpdates (ProductName CHAR(30), 
ProductDateChange CHAR(30), 
ProductOldPrice FLOAT, 
ProductNewPrice FLOAT,
PRIMARY KEY(ProductName) DISABLE);


/*Drop and create trigger to update PriceUpdates table with changes*/
DROP TRIGGER StandardPriceUpdate;
CREATE OR REPLACE TRIGGER StandardPriceUpdate AFTER UPDATE ON Product 
FOR EACH ROW WHEN (NEW.ProductStandardPrice != OLD.ProductStandardPrice)
BEGIN 
    INSERT INTO PriceUpdates VALUES (:NEW.ProductName, SYSDATE, :OLD.ProductStandardPrice, :NEW.ProductStandardPrice);
END; 
/