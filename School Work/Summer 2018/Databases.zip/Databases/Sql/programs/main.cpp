#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <list>

using namespace std;

void settypearr(string arr[], string check, int place);
string resultstr(string change, int pos, string typearr[]);

int main(){
	string tablename="";
	int numatr=0;
	cin >>numatr>>tablename;
	string typearr[numatr];
	
	

	istringstream ss;
	string temp;
	for(int i =0;i<numatr;i++){
		getline(cin,temp,',');
		settypearr(typearr,temp,i);
	}

	while(getline(cin,temp)){
		istringstream ss(temp);		
		int i =0;
		//put begining of insert here
		cout << "INSERT\nINTO "+tablename+"\nVALUES(";	
		while (getline(ss,temp, ',')){
    			cout<< resultstr(temp,i,typearr); 
			i++;
		}
		//put end of insert here
		cout << ");\n"<<endl;
	}

	return 0;
}

void settypearr(string arr[], string check, int place){
	if(check == "CHAR"){
		arr[place] = "CHAR";

	}else if(check == "INTEGER"){
		arr[place] = "INT";
	}else if(check == "FLOAT"){
		arr[place] = "FLOAT";
	}else{
		cout << "Unknown datatype"<<endl;
	}
}

string resultstr(string change, int pos, string typearr[]){
	if(typearr[pos] == "CHAR"){
		return "'"+ change + "'";
	}else if(typearr[pos] == "INTEGER"){
		return change;
	}else if(typearr[pos] == "FLOAT"){
		return change;
	}else{
		cout << "unknown data type" << endl;
	}

}
