## function to convert bit string to a number
def convert(usr):
    final=0
    for i in range(len(usr)):
        final = final+((int(usr[i]))*(2**i))
            
    return final

userin=input("what is the bit string you woulld like to convert?: ")
print("The number corrisponding to ",userin," is ",convert(userin))