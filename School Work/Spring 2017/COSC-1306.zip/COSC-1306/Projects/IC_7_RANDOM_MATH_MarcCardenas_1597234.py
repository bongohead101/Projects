import math
import random as ran

## random count 10 math count 10

##random functions
print(str(ran.getrandbits(int(input("How many bits would you like the number to be? : "))))+"\n")
print("Another random number is : "+ str(ran.random())+"\n")

## calculating cos and sin with random numbers
num=ran.randrange(1,10,1)
print("Some complicated math using the math and random function including sin and cos of a randomly generated number between 1 and 10 in this case "+str(num)+" is: \n Cos("+str(math.cos(num))+") \n Sin("+str(math.sin(num))+") \n" )

##making random variable between a range
print("Please select a range for the next random number to be (This number will only produce an integer) : ")
min=int(input("Minimum Value? : "))
max=int(input("Maximum Value? : "))
print("\n The Random integer between the range of "+str(min)+"and "+str(max)+" is "+str(ran.randint(min,max))+"\n")

## 2 randomly generated integers and finding the common divisor

def ranrange(n,x):
    final=ran.randint(n,x)
    return final

fgen=ranrange(min,max)
sgen=ranrange(min,max)
print("This line will generate 2 random variables from the range entered earlier and will output the greatist common divisor (if there is no common divisor then it will output a null): \n The first generated number is: "+str(fgen)+"\n The Second generated number is: "+str(sgen)+"\n The Common divisor is : "+ str(math.gcd(fgen,sgen)))

## factorial of 276
print("Ever wonder what the factorial 276 is? \n Well it's : "+ str(math.factorial(276)))

##the floor of a floating point number
fpn=ran.uniform(1,10)
print("The Randomly generated floating point number with a range between 1-10 is : "+str(fpn)+"\n The floor of "+str(fpn)+" is : "+str(math.floor(fpn)))

##random sample
print("A random sample from these numbers 1,2,3,4,5 are : ")
sample = ran.sample([1,2,3,4,5],3)
print(sample)
##tan of pi
print("The Tangent of pi is : "+str(math.tan(math.pi)))

##ArchTan of 2pi
print("The Arc Tan of 2pi is : "+ str(math.atan(2*math.pi)))

##Lambda
print("A randomly generated exponential distribution is : "+ str(ran.expovariate(ran.randint(1,10))))

## math e
print("The value of e in math is : "+ str(math.e))

##hyberbolic cosine
print("The inverse hyperbolic cosine of 16 is : "+ str(math.acosh(16)))

##random choice
print("The chosen letter from abcdefghijk is : "+ str(ran.choice("abcdefghijk")))

##Random shuffle
numbers=[1,2,3,4,5,6,7,8,9]
print("The numbers "+str(numbers)+" will be shuffled : ")
ran.shuffle(numbers)
print(numbers)