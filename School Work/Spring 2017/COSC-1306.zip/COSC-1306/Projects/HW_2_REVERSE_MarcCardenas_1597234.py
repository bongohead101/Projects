 ##String input
words = input("What word or phrase would you like to be reversed? : ")

def reverse(phrase):
    ##counting index
    num=int(len(phrase))
    ## making temp variable for making the string backwards
    temp=num*-1
    newphrase=''
    ## putting together the phrase backwards
    for i in range(0,num):
        newphrase=phrase[temp]+newphrase
        temp=temp+1
    return newphrase
print("The Phrase: ",words," reversed is: ",reverse(words))