print(16+4 == 4+16)

print(not (6 < 4))

print(7 >= 7)

print(7 > 7  or  7 < 7)

print(False or 1 > 0)

print("two" * 2)

print(3 * "three")

print("two" + "two")

print(2 ** 1 * 0 * 1 ** 2)

print(2 +  1 * 0 * 1 + 2)

print(7 // 3 + 9 // 5)

print(5 / 4 * 3 // 2 ** 2)

print((15//4)**(15/4))