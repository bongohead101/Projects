name="Jaycob"
lastname="Cavasos"
age="21"
address="2759 49th Street Washington 98001"
phone="832-576-9823"

print("The first name of the Employee is: ",name)
print("The last name of ", name ," is: ",lastname)
print("The age of ", name," is: ",age)
print("The address of ", name," is: ",address)
print("The phone number of ", name," is: ",phone)