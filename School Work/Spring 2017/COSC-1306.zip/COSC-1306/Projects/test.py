binary=input("What binary amount do you want in numerical form?: ")
def binConv(bin):
    num=0
    for i in range(len(bin)):
        if bin==0:
            num=num+1
        else:
            num=num+int(bin[i])*(2**i)
    return num
    
print (binConv(binary))

