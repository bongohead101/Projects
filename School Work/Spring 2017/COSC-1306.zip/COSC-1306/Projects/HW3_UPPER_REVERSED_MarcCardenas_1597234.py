##getting string from the user
userin = input("What phrase would you like to alter?: ")

##splitting the phrase by each word
usr = userin.split()

##upper case a string function
def upper(thing):
    temp = thing.upper()
    return temp

##reverse a phrase/word function
def reverse(phrase):
    ##counting index
    num=int(len(phrase))
    ## making temp variable for making the string backwards
    temp=num*-1
    newphrase=''
    ## putting together the phrase backwards
    for i in range(0,num):
        newphrase=phrase[temp]+newphrase
        temp=temp+1
    return newphrase

##selcts position and modifies each part accordingly
finishstr=''
for i in range(len(usr)):
    if (i%2==0):
        finishstr = finishstr + ' ' + upper(usr[i])
    else:
        finishstr = finishstr + ' ' + reverse(usr[i])
print("The new alered phrase is : ", finishstr)