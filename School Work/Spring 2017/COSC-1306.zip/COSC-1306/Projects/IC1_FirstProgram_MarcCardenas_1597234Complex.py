con=0
while (con != "y" or con!="yes"):
    name=input("What is the first name of the Employee?:")
    con=input("is this the correct name of the Employee? (y/n):", name)
    
print("Employee first name set!")

while (con != "y" or con!="yes"):
    lastname=input("What is the last name of the Employee?:")
    print("is this the correct name of the Employee? (y/n):", name)
    con=input("")
print("Employee last name set!")

while (con != "y" or con!="yes"):
    age=input("What is the age of the Employee?:")
    print("is this the correct age of the Employee? (y/n):", name)
    con=input("")
print("Employee age set!")

while (con != "y" or con!="yes"):
    phone=input("What is the phone number of the Employee?:")
    print("is this the correct name of the Employee? (y/n):", name)
    con=input("")
print("Employee phone number set!")

while (con != "y" or con!="yes"):
    streetaddress=input("What is the street name of the Employee's address?:")
    cityname=input("What is the city name of the Employee's address?:")
    zipcode=input("What is the zip code of the Employee's address?:")
    state=input("What is the state name of the Employee's address?:")
    po=input("Does the Employee have a P.O. Box?:(y/n)")
    if (po == "y" or po=="yes"):
        pobox=input("What is the P.O. Box Number?:")
    print(streetaddress)
    print(cityname)
    print(zipcode)
    print(state)
    if (po =="y" or po == "yes"):
        print(pobox)
    
    con=input("is this the correct address Information for the Employee? (y/n):")


print("Employee Information set!")