import math


## Into to program
print("This program is used to find the distance between two points on a graph. \n")


## Storing initial points as variables Xi and Yi
Xi=int(input("What is the X-position for the initial point? : "))

Yi=int(input("What is the y-position for the initial point? : "))

## Storing initial points as variables Xf and Yf
Xf=int(input("What is the X-position for the final point? : "))

Yf=int(input("What is the y-position for the final point? : "))

## Creating Functions
def dist(xin,yin,xfin,yfin):
    #d(P1,P2) = sqrt(  (P1x-P2x)^2   +  (P1y-P2y)^2 ) 
    ans= math.sqrt(((xin-xfin)**2) + ((yin-yfin)**2))
    return ans
    
print("The Distance between the points "+"("+str(Xi)+","+str(Yi)+") and "+"("+str(Xf)+","+str(Yf)+") is "+ str(dist(Xi,Yi,Xf,Yf)))

##Bonus!!!
print("Bonus")
shapesize=int(input("How big would you like the circles on the points to be? (radius) : "))
## Turtle drawings
import turtle
bill=turtle.Turtle()
win=turtle.Screen()

##Drawing the positions (initial)
bill.penup()
bill.goto(Xi,Yi)
bill.pendown()
bill.color("blue","blue")
bill.begin_fill()
bill.circle(shapesize)
bill.end_fill()

##Drawing the positions (Final)
bill.penup()
bill.goto(Xf,Yf)
bill.pendown()
bill.color("red","red")
bill.begin_fill()
bill.circle(shapesize)
bill.end_fill()

win.exitonclick()
print("TADA!!!")