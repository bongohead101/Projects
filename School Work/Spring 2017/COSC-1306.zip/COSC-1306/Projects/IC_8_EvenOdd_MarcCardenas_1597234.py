##Setting the user input 
num = int(input("What number should be used to test whether it is even or odd? : "))
##even odd function
def evenodd(x):
    remainder = x%2
    if (remainder == 0):
       final = "even"
    else:
       final = "odd"
    return final

print("The Number ",num," is "+ evenodd(num))