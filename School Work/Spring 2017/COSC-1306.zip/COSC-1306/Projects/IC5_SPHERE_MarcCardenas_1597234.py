    ##initialization importing use of math
import math
    ## Intro
print("This Program was created to give you data given the radius of a sphere.")

    ##Creating double or float radius
radius=float(input("What would you like the Radius of the circle to be?: "))

    ##Calculate the diameter
def diameter(r):
    temp=2*r
    return temp

    ##calculate the Circumference (4(pi)(R))
def circumference(r):
    temp2=4*math.pi*r
    return temp2

    ##Calculate Surface Area
def sfa(r):
    temp3=4*math.pi*r*r
    return temp3
    
    ##Calculate the volume
def vol(r):
    temp4=(4/3)*math.pi*r*r*r
    return temp4

    
    ##Giving the User a choice
    ##initalizing answer
ans=8

    ##Calling the Function for the users choice
while(ans!=0):

    print("1.Diameter" +'\n'+ "2.Cirumference" +'\n'+ "3.Surface Area" +'\n'+ "4.Volume" +'\n' "5.All" +'\n'+ '\n'+ "0.Exit")

    ans=int(input("Please select a number: "))
    if (ans==1):
        print("The Diameter is " + str(diameter(radius))+'\n')
    elif (ans==2):
        print("The Circumference is " + str(circumference(radius))+'\n')
    elif (ans==3):
        print("The Surface Area is " + str(sfa(radius))+ '\n')
    elif (ans==4):
        print("The Volume is " + str(vol(radius))+'\n')
    elif (ans==5):
        print("The Diameter is " + str(diameter(radius)))
        print("The Circumference is " + str(circumference(radius)))
        print("The Surface Area is " + str(sfa(radius)))
        print("The Volume is " + str(vol(radius))+'\n')
    elif (ans==0):
        print("Good Bye!")
    else:
        print("That Response is not yet supported please select one of the numbers \n")