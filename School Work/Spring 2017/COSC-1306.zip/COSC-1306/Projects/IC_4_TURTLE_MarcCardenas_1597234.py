import turtle
win= turtle.Screen()
    ## Created From Scratch
    ## Continues until counter stops
counter=0
pip = turtle.Turtle()
pip.forward(20)

tim =turtle.Turtle()
tim.color("purple")
tim.left(90)
tim.forward(20)

bob=turtle.Turtle()
bob.color("yellow")
bob.left(180)
bob.forward(20)

fred=turtle.Turtle()
fred.color("red")
fred.left(270)
fred.forward(20)

bill=turtle.Turtle()
bill.color("grey")
bill.left(45)
bill.forward(20)

lauren=turtle.Turtle()
lauren.color("blue")
lauren.left(135)
lauren.forward(20)

marc=turtle.Turtle()
marc.color("orange")
marc.left(315)
marc.forward(20)

ryan=turtle.Turtle()
ryan.color("pink")
ryan.left(225)
ryan.forward(20)

while (counter<=1000):
    

    if (counter<1000):
        pip.left(counter)
        pip.forward(counter)
  
    if (counter<1000):
        tim.left(counter)
        tim.forward(counter)
    
    if (counter<1000):
        bob.left(counter)
        bob.forward(counter)
    
    if (counter<1000):
        fred.left(counter)
        fred.forward(counter)

    if (counter<1000):
        bill.left(counter)
        bill.forward(counter)

    if (counter<1000):
        lauren.left(counter)
        lauren.forward(counter)
        
    if (counter<1000):
        marc.left(counter)
        marc.forward(counter)
        
    if (counter<1000):
        ryan.left(counter)
        ryan.forward(counter)
        counter=counter+1
        
win.exitonclick()