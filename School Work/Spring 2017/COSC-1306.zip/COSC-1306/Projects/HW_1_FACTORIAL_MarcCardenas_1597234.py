y = int(input("What integer would you like to take the factorial of? : "))
## making a function for the math process
def factorial(x):
    if x>0:
        for i in(0,x):
            
            x = x*(x-1)
        return x

print("The factorial of ", y ," is ",factorial(y))