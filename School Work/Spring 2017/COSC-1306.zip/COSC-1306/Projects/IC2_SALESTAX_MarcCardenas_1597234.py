price=float(input("What is the price of the item? : "))
taxrate=float(input("What is the sales tax in your area? : "))
tax=taxrate*price
total=(price+tax)
print("The total price of the item including tax is: ", total)