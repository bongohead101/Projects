#pragma once
#include "stdafx.h"
#ifndef H_POINT
#define H_POINT
#include <iostream>
using namespace std;
class point
{friend point outmid(point, point);

private:
	int x;
	int y;
public:
	point(int, int);
	void setall(int, int);
	int getx();
	int gety();
	void print();
	void lineeq(point);
	void distance(point);
	point midpoint(point);


};
#endif
