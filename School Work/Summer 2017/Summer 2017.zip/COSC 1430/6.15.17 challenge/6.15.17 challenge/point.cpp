#include "stdafx.h"
#include "point.h"
#include <iostream>
using namespace std;


point::point(int a, int b) {
	x = a;
	y = b;
}

void point::setall(int a, int b) {
	x = a;
	y = b;
}

int point::getx() { return x; }

int point::gety() { return y; }

void point::print() {
	cout << "(" << x << "." << y << ")" << endl;
}	

void point::lineeq(point a) {
	int m = (a.y - y) / (a.x - x);
	int b = y - m*x;
	cout << " the linear equation is \t"
		<< " y=" << m << "x+" << b << endl;

}

void point::distance(point a) {
	double d = sqrt((double)((x - a.x)*(x - a.x) + (y - a.y)*(y - a.y)));
	cout << "the distance is:\t " << d << endl;

}

point point::midpoint(point a) {
	point final(0, 0);
	final.x = (a.x - x) / 2;
	final.y = (a.y - y) / 2;
	return final;
}