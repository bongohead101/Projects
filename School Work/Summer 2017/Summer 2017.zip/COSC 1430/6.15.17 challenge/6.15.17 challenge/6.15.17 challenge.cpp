#include "stdafx.h"
#include "point.cpp"
#include <iostream>
using namespace std;

point outmid(point, point);

int main()
{
	point a(0, 0);
	point b(2, 1);
	(a.midpoint(b)).print();
	(outmid(a,b)).print();


    return 0;
}

point outmid(point a, point b) {
	point final(0, 0);
	final.x = (b.x - a.x) / 2;
	final.y = (b.x - a.x) / 2;
	return final;
}

