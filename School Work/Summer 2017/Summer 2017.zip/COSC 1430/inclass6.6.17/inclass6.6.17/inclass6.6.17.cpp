#include "stdafx.h"
#include <iostream>
using namespace std;

void f(int num) {
	if (num < 10) {
		cout << "less" << endl;
	}
	else {
		cout << "not less";
	}
}
int main()
{
	f(10);
    return 0;
}

