// write function 6.6.17.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

void curve(int[], int);
int main()
{
    return 0;
}
void curve(int a[], int asize) {
	for (int i = 0; i < asize; i++) {
		a[i] = a[i] * 110;
	}
}

