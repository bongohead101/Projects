// challenge6.6.17.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <time.h>
#include <array>
using namespace std;

int crandint(int);
void printarray(int[]);
void fillarray(int[]);
int getsizearray(int[]);


int main() {
	srand(time(0));
	int test[5] = { 1, 2, 3, 4, 5 };
	cout << "The amount of items in the test array is: " << getsizearray(test)<<endl;
	fillarray(test);
	printarray(test);

	system("pause");
	return 0;
}

int crandint(int range=100) {
	int finish = rand()%range + 1;
	return finish;
}

void printarray(int a[]) {
	int size = getsizearray(a);
	for (int i = 0; i < size; i++) {
		cout << "The number in index number : " << i << " is : " << a[i] << endl;
	}
}

int getsizearray(int a[]) {
	
	return 5;
}

void fillarray(int a[]) {
	int size = getsizearray(a);
	for (int i = 0; i < size; i++) {
		a[i] = crandint(100);
	}
}