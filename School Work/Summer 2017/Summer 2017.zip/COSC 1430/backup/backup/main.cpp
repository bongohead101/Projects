#include "memberfxn.cpp"v 
#include <iostream>
using namespace std;


int main(int argc, char*argv[]) {

	if (argc == 2) {

		fstream file;
		string temp;
		int num;
		string blank;

		file.open("input.txt", ios::in);
		getline(file, temp);
		num = stoi(temp);

		book *arr = new book[num];
		getline(file, blank);

		int i = 0;

		while (!file.eof()) {

			getline(file, temp);
			arr[i].setauthor(temp);

			getline(file, temp);
			arr[i].setname(temp);

			getline(file, temp);
			arr[i].setprice(stod(temp));

			getline(file, blank);

			i++;
		}

		for (int j = 0; j<i; j++) {
			arr[j].print();

		}

		cout << "The number of book is:\t" << book::getcount() << endl;
	}
	else { cout << "ERROR THIS PROGRAM ONLY ACCEPTS 2 ARGUMENTS" << endl; }


}