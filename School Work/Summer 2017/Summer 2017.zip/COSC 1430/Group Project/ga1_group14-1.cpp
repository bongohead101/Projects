/*Oswaldo Castro	PS:1505499
Marc Cardenas		PS:1597234
Saiful Alam			PS:1399839
*/
#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int length(const char *a);

int main() {
	char *words[10];
	int i = 0;
	int n1 = 0;
	int n2 = 0;
	int n3 = 0;
	char *t3[10];
	char *t4[10];
	char *t5[10];
	

	ifstream readfrom;
	readfrom.open("Fox.txt");
	while (readfrom)
	{
		words[i] = new char[10];

		readfrom >> words[i];

		i++;

	}


	for (int k = 0; k < 10; k++)	//this for loop will send the contents of words to the length function calculate the length
	{								// then it will use if statements to decide where to put the word based on the size of the word
		char *temp = words[k];		// so if a word say word[0] which is "the" is 3 letters long it will be stored in t3 and so on....
		int len = length(temp);

		if (len == 3)
		{
			t3[n1] = temp;
			n1++;
		}
		if (len == 4)
		{
			t4[n2] = temp;
			n2++;
		}
		if (len == 5)
		{
			t5[n3] = temp;
			n3++;
		}
	}

												//the following set of for loops will print each word then it will use a while loop to print 
												//each indivial characters vertically
		char * first = t3[0];
		cout << first << endl;
		int t = 0;
		while (first[t] != '\0')
		{
			cout << first[t] << endl;
			t++;

		}

		char*second = t5[0];
		cout << second << endl;
		int y = 0;
		while (second[y] != '\0')
		{
			cout << second[y] << endl;
			y++;
		}

		char*third = t5[1];
		cout << third << endl;
		int u = 0;
		while (third[u] != '\0') 
		{
			cout << third[u] << endl;
			u++;
		}
		char *fourth = t3[1];
		cout << fourth << endl;
		int d = 0;
		while (fourth[d] != '\0')
		{
			cout << fourth[d] << endl;
			d++;
		}
		char *fifth = t5[2];
		cout << fifth << endl;
		int h = 0;
		while (fifth[h] != '\0') 
		{
			cout << fifth[h] << endl;
			h++;
		}
		char*six = t4[0];
		cout << six << endl;
		int b = 0; 
		while (six[b] != '\0')
		{
			cout << six[b] << endl;
			b++;
		}
		char*seven = t3[2];
		cout << seven << endl;
		int q = 0;
		while (seven[q] != '\0')
		{
			cout << seven[q] << endl;
			q++;
		}
		char*eight = t4[1];
		cout << eight << endl;
		int x = 0;
		while (eight[x] != '\0')
		{
			cout << eight[x] << endl;
			x++;
		}
		char*nine = t3[3];
		cout << nine << endl;
		int f = 0;
		while (nine[f] != '\0')
		{
			cout << nine[f] << endl;
			f++;
		}
	
	for (int l = 0; l < 10; l++) // delete allocated memeory
	{
		delete[] words[l];
	}
	system("pause");

}

int length(const char *a)
{
	int l = 0;
	while (a[l] != '\0')
	{
		l++;
	}
	return l;
}
