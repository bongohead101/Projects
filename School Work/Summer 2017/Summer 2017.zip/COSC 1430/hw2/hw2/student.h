#pragma once
#include <iostream>
using namespace std;

class student {
private:
	string name;
	int numCourses;
	string* courselist;
	double* gradelist;

public:
	int numStudents;

	student(string, int, string*, double*);
	void setName(string);
	void setnumCourses(int);
	void setcourselist(string*);
	void setgradelist(double*);


};