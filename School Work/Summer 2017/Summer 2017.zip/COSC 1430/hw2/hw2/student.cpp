#include "stdafx.h"
#include "student.h"
#include <iostream>
using namespace std;

