#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


int main(int argc, char argv[])
{
	if (argc == 2) {



	}
	else { cout << "ERROR THIS PROGRAM ONLY SUPPORTS 2 ARGUMENTS" << endl; }

    return 0;
}

