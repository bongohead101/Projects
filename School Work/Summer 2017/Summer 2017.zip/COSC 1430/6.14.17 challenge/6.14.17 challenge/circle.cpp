#include "stdafx.h"
#include <iostream>
#include "circle.h"
using namespace std;

circle::circle(int a,int b,double c):point(a,b) {
	r = c;
}

void circle::setr(double a) {
	r = a;
}

void circle::setall(int a,int b,double c){
	x = a;
	y = b;
	r = c;
}

double circle::getr() { return r ;}

void circle::printall() {
	point::printall();
	cout << "The Radius is: \t" << r << endl;
}