#ifndef H_CIRCLE
#define H_CIRCLE
#include "stdafx.h"
#include <iostream>
#include "point.cpp"
using namespace std; 

class circle:protected point{
protected:
	double r;
public:
	circle(int, int, double);
	void setr(double);
	double getr();
	void setall(int, int, double);
	void printall();

};
#endif