#include "stdafx.h"
#include "point.h"
#include <iostream>
using namespace std;

point::point(int a, int b) {
	x = a;
	y = b;
}

void point::setxy(int a, int b) {
	x = a;
	y = b;
}

void point::setx(int a) {x = a;}

void point::sety(int a) {y = a;}

int point::getx() { return x; }

int point::gety() { return y; }

void point::printall() {cout << "(" << x << "," << y << ")" << endl;}

double point::distance(point a) {
	double final = sqrt((double)(x - a.x)*(x - a.x) + (y - a.y)*(y - a.y));
	return final;
}

void point::lineeq(point a) {
	double m = (a.gety() - y) / (a.getx() - x);
	double b = y - m*x;

	cout << "The equation is: \t y=" << m << "x+" << b << endl;
}

point point::midpoint(point a) {
	point final(0, 0);
	final.setx((a.x - x)/2);
	final.sety((a.y - y) / 2);
	return final;
}