#ifndef H_POINT
#define H_POINT

#include "stdafx.h"
#include <iostream>
using namespace std;

class point {
protected:
	int x;
	int y;

public:
	point(int, int);
	void setxy(int, int);
	void setx(int);
	void sety(int);
	int getx();
	int gety();
	void printall();

	double distance(point);
	void lineeq(point);
	point midpoint(point);


};
#endif