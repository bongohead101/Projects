#include "stdafx.h"
#include "point.cpp"
#include "circle.cpp"
#include <iostream>
using namespace std;

int main()
{
	point a(2, 1);
	point b(3, 2);
	point c = a.midpoint(b);
	c.printall();
	a.lineeq(b);
	cout << "The Distance between points a and b is: \t" <<a.distance(b)<<endl;



    return 0;
}

