#include "memberfxn.cpp"
#include <iostream>
#include <string>
using namespace std;


int main(int argc,char*argv[]){

	
if(atoi(argc) == 2){
	
	fstream file;
	string temp;
	int num;
	string blank;

	file.open(argv[1],ios::in);
	getline(file,temp);
	num =stoi(temp);
	student *arr=new student[num];
	getline(file,blank);
	
	int i=0;
	
	while(!file.eof()){
	
		getline(file,temp);
		arr[i].setname(temp);

		getline(file,temp);
		arr[i].setnumCourses(temp);

		getline(file,temp);
		//fill class list array here using arr[i]
		
		

		cout << temp <<endl;

		getline(file,temp);
		//fill grade array here using arr[i]
		
		
		getline(file,blank);
		
		i++;	
	}
	


	cout << "The number of students is:\t" <<student::getcount() <<endl;
}
else{cout << "ERROR THIS PROGRAM ONLY ACCEPTS 2 ARGUMENTS"<<endl;}


}