#ifndef H_CLASSES
#define H_CLASSES
#include <string>
#include <iostream>
using namespace std;

class student{

	private:
		string name;
		int numCourses;
		string *courseList[];
		string *gradeList[];
		double gpa;
		
		static int numStudents;
	public:
		student();
		student(string="name",int = 1);
		void setname(string);
		void setnumCourses(int);
		void setcourseList(string&);
		string getname();
		int getnumCourses();
		string getcourseList();
		void calcgpa();
		double getgpa();
		static int getcount();
		void empty();
		void print();
		~student();


};
#endif
