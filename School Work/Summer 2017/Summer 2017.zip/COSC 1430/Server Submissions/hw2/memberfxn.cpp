#include "classes.h"
#include <iostream>
using namespace std;


int student::numStudents=0;

student::student(){
	name = "student";
	numCourses = 1;
	numStudents++;
	
}
student::student(string a,int b){

	name = a;
	numCourses =b;
	numStudents++;
}
void student::setname(string a){name = a;}

void student::setnumCourses(int a){numCourses = a;}
	
void student::setcourseList(&string a){courseList = a;}

string student::getname(){return name;}

int student::getnumCourses(){return numCourses;}

string student::getcourseList(){return courseList;}

void student::print(){
	cout << "Name:\t" <<name <<endl;
	cout << "Courses:\t";
	
	for (int i=0;i<numCourses;i++){
		cout<<courseList[i]<<"   ";
	}
	cout <<endl;
	
	cout << "Grades:\t";
	for(int i =0;i<numCourses;i++){
		cout <<gradeList[i];<<"   ";
	}
	cout << endl;
	
}

void student::calcgpa(){
	
	gpa=0;
	double creds=0;
	
	for(int i=0;i<numCourses;i++){
	if(gradeList[i] =="A"){
		gpa+= 4.0;
	}else if (gradeList[i] =="A-" ||gradeList[i] =="-A"){
		gpa+= 3.66;
	}else if (gradeList[i] =="+B" ||gradeList[i] =="B+"){
		gpa+= 3.33;
	}else if (gradeList[i] =="B"){
		gpa+= 3.0;
	}else if (gradeList[i] =="B-" ||gradeList[i] =="-B"){
		gpa+= 2.66;
	}else if (gradeList[i] =="C+" ||gradeList[i] =="+C"){
		gpa+= 2.33;
	}else if (gradeList[i] =="C"){
		gpa+= 2.0;
	}else if (gradeList[i] =="C-" ||gradeList[i] =="-C"){
		gpa+= 1.66;
	}else if (gradeList[i] =="+D" ||gradeList[i] =="D+"){
		gpa+= 1.33;
	}else if (gradeList[i] =="D"){
		gpa+= 1.0;
	}else if (gradeList[i] =="-D" ||gradeList[i] =="D-"){
		gpa+= 0.66;
	}else if (gradeList[i] =="F"){
		gpa+= 0;
	}else{
		gpa+=0;
	}
	creds+=3.0;
	
	}
	
	gpa= gpa/creds;
	
	
}

double student::getgpa(){
	calcgpa();
	return gpa;
	
}

static int student::getcount(){
	return numStudents;
}

void student::empty(){
	for(int i =0; i<numCourses;i++){
		courseList[i]="";
		gradeList[i]=0;
	}
	numCourses=0;
}

student::~student(){
	cout << "Student Destroyed"<<endl;
}