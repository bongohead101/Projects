#include <iostream>
#include <fstream>
using namespace std;

class money{
	private:
		int dol;
		int cent;
	public:
		money(int=0,int=0);
		int getdol();
		int getcent();
		void setdol(int);
		void setall(int,int);
		

};

money operator +(money,money);
void operator +(int,money&);

int main(){

	int c;
	money a(1,20);
	money b(2,3);
	cout << (a+b).getdol()<<endl;
	cout << a.getdol()<<endl;
	10+a;
	cout << a.getdol()<<endl;

}

void operator +(int a,money& b){
	
	cout << "object start is "<<b.getdol()<<endl;
	cout << "int passed is: "<< a<<endl;
	int c =b.getdol()+a;
	cout << "c is :" << c <<endl;
	b.setdol(c);

}

money operator +(money a,money b){
	money temp(0,0);
	int dol = a.getdol()+b.getdol();
	int cent = a.getcent() + b.getcent();
	if (cent >= 100){
		dol++;
		cent-=100;
	}
	temp.setall(dol,cent);
	return temp;
}

money::money(int a,int b){setall(a,b);}

void money::setall(int a,int b){
	dol=a;
	cent=b;}

void money::setdol(int a){dol =a;}

int money::getdol(){return dol;}

int money::getcent(){return cent;}
