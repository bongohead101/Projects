#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;

struct student {
	int id;
	int grade;
};



int main()
{
	srand(time(0));
	int a[10];
	fstream file;
	student *p = new student[10];


	file.open("file.txt", ios::out); // gen id
	for (int i = 0; i < 9; i++) {
		a[i] = 1000 + rand() % 1000;
		file << a[i] << endl;
		}
		a[9] = 1000 + rand() % 1000; // it was count the endl so i ran the last instance without it
		file << a[9];
	file.close();

	file.open("file.txt", ios::in); //setting ids
	int i = 0;
	while (!file.eof()) {
		file >> p->id;
		p->grade = 0;
		p++;
	}
	p -= 10; // resetting pointer
	

	for (int i = 0; i < 10; i++) { // setting grades
		p->grade = rand() % 101;
		p++;
	}
	p -= 10; // resetting pointer

	for (int i = 0; i < 10; i++) { //printing final
		cout << "ID: "<< p->id << "\t GRADE: " << p->grade << "\t"<< endl;
		p++;

	}
	p -= 10; // resetting pointer

    return 0;
}

