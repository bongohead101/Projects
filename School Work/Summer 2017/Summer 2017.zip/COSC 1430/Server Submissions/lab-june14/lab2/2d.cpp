#include <iostream>
#include <time.h>
using namespace std;

int main(int argc, char *argv[]){
	
	srand(time(0));

	if(argc == 3){

		int a1 = atoi(argv[1]);
		int a2 = atoi(argv[2]);
		int biggest=0;

		if(a1>0 && a2>0){

			int **arr;
			arr = new int*[a1];
			
			
			for (int i = 0; i<a1;i++){
				
				arr[i]= new int[a2];			

			}

			for(int i = 0; i<a1; i++){

				for(int j = 0; j<a2; j++){

					arr[i][j]=rand()%10+1;
					cout << arr[i][j] <<"\t";
					if(arr[i][j] > biggest){
						biggest = arr[i][j];
					}

				}
				
				cout << endl;
			}

			cout << "The biggest number in the matrix is: "<<biggest<<endl;			
	
			for(int i = 0 ; i<a1;i++){

				delete[] arr[i];

			}
			delete[] arr;

		}
		else{
		cout << "ARGUMENTS CAN NOT BE NEGATIVE"<<endl;
		exit(1);
		}

	

	}else{
	cout << "PROGRAM ONLY SUPPORTS 2 ARGUMENTS"<<endl;
	exit(1);
	}

}
