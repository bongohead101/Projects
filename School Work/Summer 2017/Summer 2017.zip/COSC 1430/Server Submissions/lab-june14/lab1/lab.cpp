#include <iostream>
#include <time.h>
using namespace std;

int main(int argc, char *argv[]){
srand(time(0));
if (argc == 2){
int given = atoi(argv[1]);
if (given>=0){
	int *p = new int[given];
	int sum = 0;
	for (int i = 0; i < given; i++){
		*p = rand()%10 +1;	
		sum += *p;
		cout << *p << endl;
		p++;

	}
	p-=given;
	cout << "The sum of the numbers are: "<<sum<<endl;

	delete[] p;
	
	return 0;
}
else{
cout << "ARGUMENT CAN NOT BE NEGATIVE"<< endl; 
exit(1);
}

}
else{
	cout << "ERROR THIS PROGRAM REQUIRES 2 ARGUMENTS"<< endl;
	exit(1);
}
}

