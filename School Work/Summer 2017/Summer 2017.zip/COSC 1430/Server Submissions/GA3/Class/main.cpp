/*
	Oswaldo Castro PSID 1505499
	Marc Cardenas  PSID 1597234

*/
#include<iostream>
#include<time.h>
using namespace std;

class Calculator {

	friend void friendaddition(Calculator, Calculator); 
	friend ostream& operator <<(ostream& outputstream, Calculator& cal3);
	friend istream& operator >>(istream& , Calculator&);


private:
	int a[10];
	int val1;
	int val2;
	double val3;
	int index;
public:
	Calculator();
	void setVal1();
	void setVal2();
	void setVal3(double);
	int getVal1();
	int getVal2();
	double getVal3();
	void setindex();
	void printarray();
};

Calculator operator+(Calculator a, Calculator b)
{
	Calculator temp;
	temp.setVal3(a.getVal1() + b.getVal2());
	return temp;
}
Calculator operator-(Calculator a, Calculator b)
{
	Calculator temp;
	temp.setVal3(a.getVal1() - b.getVal2());
	return temp;
}
Calculator operator*(Calculator a, Calculator b)
{
	Calculator temp;
	temp.setVal3(a.getVal1() * b.getVal2());
	return temp;
}
 Calculator operator / (Calculator a, Calculator b)
{
	Calculator temp;
	temp.setVal3(((double)a.getVal1()) / ((double)b.getVal2()));
	return temp;
}

void friendaddition(Calculator a, Calculator b)
 {
	int faddition = (a.getVal1() + b.getVal2());
	cout << faddition << endl;
 }
 
 void Calculator::printarray()
 {
 	for(int i=0; i<9;i++)
 	{
 		cout<<a[i]<<", ";
 	}
 	cout<<a[9]<<endl;
 }

ostream& operator <<(ostream& outputstream, Calculator& cal3)
{
	outputstream << cal3.getVal3();
	return outputstream;
}
istream& operator >> (istream& inputstream, Calculator& result)
{
	for(int i = 0; i<10; i++)
	{
	 cout << "What number would you like it input int array position "<< i << ": ";
	 inputstream >> result.a[i];
	 cout<<endl;
	}
	return inputstream;
}

 

Calculator::Calculator()
{
	for (int i = 0; i < 10; i++)
	{
		a[i] = i;
		
	}
	setindex();
}
void Calculator::setindex() {index = a[rand() % 10];}
void Calculator::setVal1() {val1 = index;}
void Calculator::setVal2() {val2 = index;}
void Calculator::setVal3(double t) { val3 = t;}
int Calculator::getVal1() {return val1;}
int Calculator::getVal2() {return val2;}
double Calculator::getVal3() {return val3;}

int main() {
	srand(time(0));
	Calculator cal1, cal2, cal3,in;
	cal1.setVal1();
	cal2.setVal2();
	cout << "These are the values chosen at random from the array : "<< cal1.getVal1()<<" , "<< cal2.getVal2()<<endl;
	cal3 = cal1 + cal2;
	cout << "Addition : ";
	cout << cal3 << endl;
	cal3 = cal1 - cal2;
	cout << "Subtraction : ";
	cout << cal3 << endl;
	cal3 = cal1 * cal2;
	cout << "Multiplication : ";
	cout<< cal3 << endl;
	cal3 = cal1 / cal2;
	cout << "Division : ";
	cout << cal3 << endl;
	cout << "Friend Addition :";
	friendaddition(cal1, cal2);
	cin >> in;
	in.printarray();
	
	  
	return 0;
}










































