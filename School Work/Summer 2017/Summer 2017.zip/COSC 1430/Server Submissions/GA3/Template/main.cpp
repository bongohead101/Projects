/*
    Marc Cardenas PSID 1597234
    Saiful Alam   PSID 1399839 
    Oswaldo Castro PSID 1505499
*/
#include <iostream>
#include <time.h>
using namespace std;

//////////////////////////////////////////////////////////////////////////////
//class calculator
template <class T, class U>
class calculator{
    private :
    T param1;
    U param2;
    T result;
    int array[10];      //0-9
    int index;         //index for rand num in array of 0-9
    int index2;         //2nd index for rand num in array of 0-9
    public:
        //friend functions
            
            template <class A,class B, class C, class D>
            friend calculator<A,B> friendadd(calculator<A,B>,calculator<C,D>);
            
            
            template <class Y, class Z>
        	friend ostream& operator <<(ostream&,const calculator<Y,Z>);
        	
        	template <class Y, class Z>
        	friend istream& operator >>(istream&,calculator<Y,Z>&);
        	
    
        //end friend functions
        calculator(T=0,U=0);
        void setindex();        //gets a number from the array
        void setparam1(T);
        void setparam2(U);
        void setresult(T);
        void printarray();
        T getresult();
        T getparam1();
        U getparam2();
};
//end class calculator
///////////////////////////////////////////////////////////////////////////////
//prototypes
template <class T, class U,class V,class W>
calculator<T,U> operator+(calculator<T,U> a, calculator<V,W> b);

template <class T, class U,class V,class W>
calculator<T,U> operator-(calculator<T,U> a, calculator<V,W> b);

template <class T, class U,class V,class W>
calculator<T,U> operator*(calculator<T,U> a, calculator<V,W> b);

template <class T, class U,class V,class W>
calculator<T,U> operator/(calculator<T,U> a, calculator<V,W> b);


//end prototypes
//////////////////////////////////////////////////////////////////////////////
//main functions
int main(){
    srand(time(0));
    
    
    
    calculator<float,double> cal1(38.256,2.38);
    calculator<int,int> cal2(89.89,35.21);
    cout << cal1.getparam1() << endl;
    cout << (cal1+cal2).getresult() << endl;
    cout << (cal1-cal2).getresult() << endl;
    cout << (cal1*cal2).getresult() << endl;
    cout << (cal1/cal2).getresult() << endl;
    cal1.setresult(23);
    cout << cal1<< endl;
    cout << friendadd(cal1,cal2) <<endl;
    
    cin >> cal1;
    cal1.printarray();
    
    return 0;
}
//end main
//////////////////////////////////////////////////////////////////////////////
//main functions
template <class A, class B,class C,class D>
calculator<A,B> friendadd(calculator<A,B> a,calculator<C,D> b) {
    calculator<A,B> temp;
    temp.setresult(a.param1+b.param1);
    return temp;
}

//end main functions
///////////////////////////////////////////////////////////////////////////////
//overloading operators

template <class Y, class Z>
istream& operator >>(istream& inputstream,calculator<Y,Z>& a)
{
    for (int i =0 ; i< 10;i++){
        cout << "What number would you like it input int array position "<< i << ": ";
        inputstream >>a.array[i];
        cout <<endl;
    }
    
    
    return inputstream;
}

template <class Y, class Z>
ostream& operator <<(ostream& outputstream,const calculator<Y,Z> a)
{
	outputstream << a.result;
	return outputstream;
}

//addition returning a calculator object
template <class T, class U,class V,class W>
calculator<T,U> operator+(calculator<T,U> a, calculator<V,W> b)
{
	calculator<T,U> temp;
	temp.setresult(a.getparam1() + b.getparam1());
	return temp;
}

//subtraction returning a calculator object
template <class T, class U,class V,class W>
calculator<T,U> operator-(calculator<T,U> a, calculator<V,W> b)
{
	calculator<T,U> temp;
	temp.setresult(a.getparam1() - b.getparam1());
	return temp;
}

//multiplication returning a calculator object
template <class T, class U,class V,class W>
calculator<T,U> operator*(calculator<T,U> a, calculator<V,W> b)
{
	calculator<T,U> temp;
	temp.setresult(a.getparam1() * b.getparam1());
	return temp;
}

//division returning a calculator object
template <class T, class U,class V,class W>
calculator<T,U> operator/(calculator<T,U> a, calculator<V,W> b)
{
	calculator<T,U> temp;
	temp.setresult(a.getparam1() / b.getparam1());
	return temp;
}
//end overloading operators
//////////////////////////////////////////////////////////////////////////////
// class functions

template <class T, class U>
calculator<T,U>::calculator(T a,U b){
    param1 =a;
    param2 =b;
    for (int i=0; i<10;i++){array[i]=i;}
    setresult(0);
    
}

template <class T, class U>
void calculator<T,U>::setindex(){index = rand()%10; index2 = rand()%10;}

template <class T, class U>
void calculator<T,U>::setparam1(T a){param1 = a;}

template <class T, class U>
void calculator<T,U>::setparam2(U a){param2 = a;}

template <class T, class U>
T calculator<T,U>::getparam1(){return param1;}

template <class T, class U>
U calculator<T,U>::getparam2(){return param2;}

template <class T, class U>
void calculator<T,U>::setresult(T a){result =a;}

template <class T, class U>
T calculator<T,U>::getresult(){return result;}

template <class T, class U>
void calculator<T,U>::printarray(){
    for (int i=0; i<9; i++){
        cout <<array[i]<<", ";    
    }
     cout <<array[9]<<endl;  
}