#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
using namespace std;
////////////////////////////////////////////////////////////////////////////
//start array sort class
template<class T>
class arraysort{
    private:
        int size;
        T *unsorted_arr;
        T *sorted_arr;
    public:
        
        arraysort();
        void fillarray();
        void fillarrayc();
    	void setsize(int);
	    void sortarr();
	    void rsortarr();
	    int getsize();
	    void setunsorted_arr(T a, int i);
	    T getunsorted_arr();
	    T getsorted_arr();
	    void printall();
	    
};
//end array sort class
/////////////////////////////////////////////////////////////////////////////
//begin holder
template <class U>
class holder{
	
	private:
		U element;
		
	public:
	
		///////////////////////////////////////////////////////////////////
		//friend functions
			template <class X>
			friend ostream& operator <<(ostream&,holder<X>);
			
			template<class X>
			friend istream& operator >>(istream&, holder<X>&);
			
			
		//end friend functions	
		///////////////////////////////////////////////////////////////////
	
	
		holder();
		holder(U);
		void setelement(U);
		U getelement();
		~holder();
};
/////////////////////////////////////////////////////////////////////////////
//begin main
template<class Z>
void callint(int,int);
int main(int argc,char*argv[]){
    srand(time(0));
	if (argc == 3){
			if (argv[1]>0 &&(stoi(argv[2])==1 || stoi(argv[2])==2)){
				
				int arg1 = stoi(argv[1]);
				int arg2 = stoi(argv[2]);
				
				cout <<"For the template INT: "<<endl;
				callint<int>(arg1,arg2);
				cout <<"For the template DOUBLE: "<<endl;
				callint<double>(arg1,arg2);
				cout <<"For the template FLOAT: "<<endl;
				callint<float>(arg1,arg2);
				cout <<"For the template CHAR: "<<endl;
				callint<char>(arg1,arg2);
				
				
				
				
				
    			return 0;
			}else {cout << "ERROR FIRST ARGUMENT MUST BE POSITIVE AND \n SECOND ARGUMENT MUST BE EITHER 1 OR 2"<<endl;exit(1);}
	}else{cout << "ERROR THERE MUST 2 ARGUMENTS"<<endl; exit (1);}
}
//end main
///////////////////////////////////////////////////////////////////////////////
//main functions
template<class Z>
void callint(int a,int arg2){
	Z arr[a];
				holder<Z> *p = new holder<Z>[a];
				
				for (int i=0; i<a;i++){
					cout << "What would you like element at position "<< i <<" to be?: ";
					cin >> p[i];
					cout <<endl;
					arr[i]=p[i].getelement();
				}
				
				cout << "The array of holders is : [";
				for (int i =0; i<a;i++){
					cout << p[i] <<" ";
				}
				cout <<"]"<<endl;
				
				arraysort<Z> test;
				test.setsize(a);
				for (int i=0; i<a;i++){
					test.setunsorted_arr(arr[i],i);
				}
				
				if(arg2 == 1){
					test.sortarr();
				}else{
					test.rsortarr();
				}
				
				test.printall();
}
//end main functions
//////////////////////////////////////////////////////////////////////////////
//overloading functions
template<class U>
holder<U> operator +=(holder<U> a, U b){
	holder<U> temp;
	temp.setelement(a.getelement()+b);
	return temp;
}
template<class U>
ostream& operator <<(ostream& a,holder<U> b){
	a << b.element;
	return a;
}
template<class U>
istream& operator >>(istream& a,holder<U>& b){
    a >>b.element;
	return a;
}
//end overloading functions
///////////////////////////////////////////////////////////////////////////////
//holder functions
template <class U>
holder<U>::holder(){
	element = 0;
}
template<class U>
holder<U>::holder(U a){
	element  = a;
}
template <class U>
holder<U>::~holder(){}
template<class U>
void holder<U>::setelement(U a){
	element  = a;
}
template<class U>
U holder<U>::getelement(){
	return element;
}
//end holder functions
///////////////////////////////////////////////////////////////////////////////
//array functions start
template <class T>
arraysort<T>::arraysort(){
	size =0;
}
template <class T>
void arraysort<T>::setsize(int a){
	size = a;
	unsorted_arr=new T[size];
    sorted_arr=new T[size];
}
template <class T>
void arraysort<T>::fillarray(){
	for(int i = 0; i < size; i++){
		unsorted_arr[i] =1+rand()%100+1;
	}
}
template <class T>
void arraysort<T>::setunsorted_arr(T a, int i){
	unsorted_arr[i]=a;
}
template<class T>
void arraysort<T>::fillarrayc(){
	for(int i = 0; i < size; i++){
		unsorted_arr[i] +=(char)(65+rand()%25+1);
	}
}
template <class T>
void arraysort<T>::sortarr(){
	
	for (int i=0;i<size;i++){
	sorted_arr[i]=unsorted_arr[i];	
	}
	for(int i =size-1; i>0;i--){
		for(int j=0;j<i;j++){
			if(sorted_arr[j]>sorted_arr[j+1]){
				T temp = sorted_arr[j+1];
				sorted_arr[j+1]=sorted_arr[j];
				sorted_arr[j]=temp;
			}
		}
	
	}
}
template <class T>
void arraysort<T>::rsortarr(){
	
	for (int i=0;i<size;i++){
	sorted_arr[i]=unsorted_arr[i];	
	}
	for(int i =size-1; i>0;i--){
		for(int j=0;j<i;j++){
			if(sorted_arr[j]<sorted_arr[j+1]){
				T temp = sorted_arr[j+1];
				sorted_arr[j+1]=sorted_arr[j];
				sorted_arr[j]=temp;
			}
		}
	
	}
}
template<class T>
int arraysort<T>::getsize(){return size;}
template<class T>
T arraysort<T>::getunsorted_arr(){return *unsorted_arr;}
template<class T>
T arraysort<T>::getsorted_arr(){return *sorted_arr;}
template<class T>
void arraysort<T>::printall(){
	cout << "The size of the array is: "<<size <<endl;
	cout << "The unsorted array is: [";
		for (int i = 0; i<size; i++){
		
			cout <<unsorted_arr[i] <<" ";
		}	
		cout << "]"<<endl;
	cout << "The sorted array is: [";
                for (int i = 0; i<size; i++){
                        cout <<sorted_arr[i] <<" ";
                }
                cout << "]"<<endl;
}
//end arraysort functions

