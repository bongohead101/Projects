#include <typeinfo>
#include <iostream>
#include <time.h>
using namespace std;

double crand(int);

int main(int argc, char *argv[]){
	
	srand(time(0));

	if(argc == 3){

		int a1 = atoi(argv[1]);
		int a2 = atoi(argv[2]);
		double a1d = (double)a1;
		double a2d = (double)a2;
		double biggest=0;
		double smallest = a2;

		if(a1>0 && a2>0){

			double **arr;
			arr = new double*[a1];
			double **arr2;
			arr2= new double*[a1];
			double **arr3;
			arr3= new double*[a1];

			//ini final matrix
			 for (int i = 0; i<a1;i++){

                                arr3[i]= new double[a2];

                        }

                        for(int i = 0; i<a1; i++){

                                for(int j = 0; j<a2; j++){

                                        arr3[i][j]=0.0;

                                }

                                cout << endl;
                        }


			//finish ini final matrix

			//start first matrix
			for (int i = 0; i<a1;i++){
				
				arr[i]= new double[a2];			

			}

			for(int i = 0; i<a1; i++){

				for(int j = 0; j<a2; j++){

					arr[i][j]=crand(a1);
					arr3[i][j] += (arr[i][j]);
					cout << arr[i][j] <<"\t";

				}
				
				cout << endl;
			}
			//end 1st matrix
			cout << endl<<"\t+"<<endl << endl;
			//2nd matrix
			 for (int i = 0; i<a1;i++){

                                arr2[i]= new double[a2];

                        }

                        for(int i = 0; i<a1; i++){

                                for(int j = 0; j<a2; j++){

                                        arr2[i][j]=crand(a2);
					arr3[i][j]+=(arr2[i][j]);
                                        cout << arr2[i][j] <<"\t";

                                }

                                cout << endl;
                        }
			//end 2nd matrix

			cout << endl << "\t ="<< endl<<endl;
 
			for (int i =0; i < a1; i++){

				for(int j = 0; j<a2;j++){

					cout<<arr3[i][j]<< "\t";
					if(arr3[i][j]>biggest){

						biggest = arr3[i][j];

					}
					if(arr3[i][j]<smallest){
					
						smallest=arr3[i][j];

					}
				}
				cout<<endl;
			}
			cout <<endl;
			cout << "The Biggest number is: "<< biggest<<endl;
			cout << "The Smallest number is: "<< smallest<<endl<<endl;

			





			for(int i = 0 ; i<a1;i++){

				delete[] arr[i];
				delete[] arr2[i];
				delete[] arr3[i];				

			}
			delete[] arr;
			delete[] arr2;
			delete[] arr3;
		}
		else{
		cout << "ARGUMENTS CAN NOT BE NEGATIVE"<<endl;
		exit(1);
		}

	

	}else{
	cout << "PROGRAM ONLY SUPPORTS 2 ARGUMENTS"<<endl;
	exit(1);
	}

}


double crand(int range = 10){

	double final = (double)(rand()%range-1);
	double dec = (double)((rand()%100)/100.0);
	final+=dec;

	int temp = rand()%2;
	if(temp != 0){
	final = -1.0*final;
	}

	if (final < (range)){
	
	final++;
	return final;
	}
	if (final > range){

	final--;
	return final;

	}
	return final;

}
