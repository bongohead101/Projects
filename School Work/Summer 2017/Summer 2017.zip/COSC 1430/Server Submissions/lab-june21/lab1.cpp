#include <iostream>
#include <fstream>
using namespace std;

class book{

	private:
		string bookname;
		string authorname;
		double price;
		static int numBooks;
	public:
		book(string ="book",string = "author",double=0.0);
		void setname(string);
		void setauthor(string);
		void setprice(double);
		string getname();
		string getauthor();
		double getprice();
		static int getcount();
		void print();
		~book();


};



int main(){
	
	fstream file;
	string temp;
	int num;
	string blank;

	file.open("input.txt",ios::in);
	getline(file,temp);
	num =stoi(temp);

	book *arr=new book[num];
	getline(file,blank);
	
	int i=0;
	
	while(!file.eof()){
	
		getline(file,temp);
		arr[i].setauthor(temp);

		getline(file,temp);
		arr[i].setname(temp);

		getline(file,temp);
		arr[i].setprice(stod(temp));

		getline(file,blank);
		
		i++;	
	}
	
	for (int j=0;j<i;j++){
		arr[j].print();

	}

	cout << "The number of book is:\t" << book::getcount() <<endl;



}


//book functions

int book::numBooks=0;

book::book(string a,string b,double c){
	bookname = a;
	authorname=b;
	price =c;
	numBooks++;
}

void book::setname(string a){bookname=a;}

void book::setauthor(string a){authorname=a;}

void book::setprice(double a){price = a;}

string book::getname(){return bookname;}

string book::getauthor(){return authorname;}

double book::getprice(){return price;}

void book::print(){

	cout << "For book:\t"<< bookname<<endl;
	cout<< "The author is:\t" <<authorname<<endl;
	cout << "The Price is:\t"<<price<<endl;
	cout<<endl;
}

int book::getcount(){return numBooks;}

book::~book(void){ cout << "Book was deleted" <<endl;}
