#include <iostream>
#include <string>
#include <time.h>
using namespace std;

class ArraySort{

private:
	int size;
	int *unsorted_arr;
	int *sorted_arr;
public:

	ArraySort();
	void fillarray();
	void setsize(int);
	void sortarr();
	void rsortarr();
	int getsize();
	int getunsorted_arr();
	int getsorted_arr();
	void printall();
};


int main(int argc, char*argv[]){
if (argc==2){
	srand(time(0));

	int num = stoi(argv[1]);


	ArraySort thing;
	thing.setsize(num);
	thing.fillarray();
	thing.sortarr();
	thing.printall();

	return 0;

}
else{
	cout <<"ERROR THIS PROGRAM ONLY ACCEPTS 2 ARGUMENTS"<<endl;
}



}

ArraySort::ArraySort(){
	size =0;
}

void ArraySort::setsize(int a){

	size = a;
	unsorted_arr=new int[size];
        sorted_arr=new int[size];
}

void ArraySort::fillarray(){
	for(int i = 0; i < size; i++){
		unsorted_arr[i] =1+rand()%100+1;
	}
}

void ArraySort::sortarr(){
	
	for (int i=0;i<size;i++){

	sorted_arr[i]=unsorted_arr[i];	

	}

	for(int i =size-1; i>0;i--){
		for(int j=0;j<i;j++){
			if(sorted_arr[j]>sorted_arr[j+1]){
				int temp = sorted_arr[j+1];
				sorted_arr[j+1]=sorted_arr[j];
				sorted_arr[j]=temp;
			}
		}
	
	}

}

int ArraySort::getsize(){return size;}

int ArraySort::getunsorted_arr(){return *unsorted_arr;}

int ArraySort::getsorted_arr(){return *sorted_arr;}

void ArraySort::printall(){

	cout << "The size of the array is: "<<size <<endl;
	cout << "The unsorted array is: [";
		for (int i = 0; i<size; i++){
		
			cout <<unsorted_arr[i] <<" ";

		}	
		cout << "]"<<endl;

	cout << "The sorted array is: [";
                for (int i = 0; i<size; i++){

                        cout <<sorted_arr[i] <<" ";

                }
                cout << "]"<<endl;

}

