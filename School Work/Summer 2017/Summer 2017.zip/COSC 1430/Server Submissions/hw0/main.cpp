#include <iostream>
using namespace std;


int main(int argc, char *argv[])
{
	int summation=0;
	int i = 1;
	int num = 5; //figure out how to recieve input from command line when running compiled program
	num = atoi(argv[1]);

	if (argc == 2) // check for amount of argumrnts
	{
	if (num > -1){ //checks if the number is a non negative
		while (i != (num + 1)) { //prints out numbers til it reaches the specified number (num)
			cout << i << endl;
			summation = summation + i;
			i++;
		}
	cout << "Summation is: " << summation << endl; //prints the sumation
	}
	else
	{
		cout << "ERROR PROGRAM DOES NOT ACCEPT NEGATIVE NUMBERS" << endl; //prints error code if number is negative
	}
	}
	else
	{
		cout << "ERROR PROGRAM CAN ONLY SUPPORT 2 ARGUMENTS" << endl; //prints error code if there are more than 2 arguments
	}



    return 0;
}

