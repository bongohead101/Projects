#include <iostream>
#include <string>
using namespace std;

int main(int argc,char *argv[]){

if (argc == 3){

int num1 = atoi(argv[1]);
int num2 = atoi(argv[2]);

int sum = num1 +num2;

cout << num1 <<" + "<< num2<< " = "<<sum << endl;
}
else{

 cout << "This program only supports 3 arguments." << endl;

}
}
