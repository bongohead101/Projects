#include <iostream>
using namespace std;

int main(int argc, char *argv[]){

int num = atoi(argv[1]);
int final = 1;

for(int i=1; i<=num; i++){

final = final * i;

}

cout << "The Factorial of " << num <<" is: " << final<< endl;

}
