#ifndef H_ANIMAL
#define H_ANIMAL
#include <iostream>
using namespace std;


//base class
class animal
{
private:
    static int count;
    
public:
	animal();

	virtual void speak() = 0;
	static int counter;
	static void getCount();
};

class canine :public animal {
private:
    static int count;
    
public:
	canine();
	static int counter;
	virtual void speak();
	static void getCount();
};

class feline :public animal {
private:
    static int count;
    
public:
	feline();
	static int counter;
	virtual void speak();
	static void getCount();
};

class dog :public canine {
private:
	string name;
	static int count;
public:
	dog();
	dog(string);
	void speak();
	string getName();
	static void getCount();
};

class wolf :public canine {
private:
    static int count;
    
public:
	wolf();
	string howl();
	void speak();
	static void getCount();
};

class cat :public feline {
private:
	string name;
	static int count;
public:
	cat();
	cat(string);
	void speak();
	string getName();
	static void getCount();

};



#endif