/*
Marc Cardenas PSID 1597234
Oswaldo Castro PSID 1505499
*/
#include <iostream>
#include<iomanip>
#include<string.h>
#include "memberfxn.cpp"
using namespace std;

int main() {
	cout << "Hello World!" << endl;
	cat done;
	dog dtwo;
	wolf dthree;
	dog one("Sparky");
	cat two("Mittens");
	
	//pointers
    canine *Canine1 = new canine;
    feline *Feline1 = new feline;
    dog *Dog1 = new dog;
    cat *Cat1 = new cat;
    wolf *Wolf1 = new wolf;


    cout << "The name of the named dog is:\t" << one.getName()<<endl;
    cout << "The name of the named cat is:\t" << two.getName()<<endl;
    cout << endl;

    //pointer array of type animal
    animal *Animal[5];

    //here we assign array pointers to pointers of different inherited classes
    Animal[0] = Canine1;
    Animal[1] = Feline1;
    Animal[2] = Dog1;
    Animal[3] = Cat1;
    Animal[4] = Wolf1;
    
    for (int i = 0; i < 5; i++)
    {
        Animal[i]->speak();
    }
    cout << endl;
    
    
    
    

    animal::getCount();
    canine::getCount();
    feline::getCount();
    dog::getCount();
    cat::getCount();
    wolf::getCount();


	return(0);
}



