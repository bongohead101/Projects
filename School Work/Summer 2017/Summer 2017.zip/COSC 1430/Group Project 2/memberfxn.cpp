#include <iostream>
#include "classes.h"
using namespace std;


animal::animal()
{
	counter++;
	count++;

}
int animal::counter = 0;

void animal::getCount()
{
    cout << "The number of animals is " << count << endl;
}

void animal::speak()
{
    
}
//////////////////////////////
canine::canine()
{
	counter++;
	count++;
}
int canine::counter = 0;
void canine::speak()
{
    cout << "WOOF" << endl;
}

void canine::getCount()
{
    cout << "The number of canines is " << count << endl;
}
/////////////////////////////

feline::feline()
{
	counter++;
	count++;
}
int feline::counter = 0;

void feline::speak()
{
    cout << "PURR" << endl;
}

void feline::getCount()
{
    cout << "The number of felines is " << count << endl;
}
////////////////////////////
dog::dog()
{
	name = "dog";
	count++;

}

dog::dog(string a)
{
	name = a;
	count++;

}

string dog::getName()
{
	return name;

}

void dog::getCount()
{
    cout << "The number of dogs is " << count << endl;
}

void dog::speak()
{
    cout << "WOOF" << endl;
}
/////////////////////////////
wolf::wolf() {count++;}

string wolf::howl()
{
	return "HOWL";

}

void wolf::getCount()
{
    cout << "The number of wolves is " << count << endl;
}

void wolf::speak()
{
    cout << "HOWL" << endl;
}
///////////////////////////////
cat::cat()
{
	name = "cat";
	count++;

}

cat::cat(string a)
{
	name = a;
  count++;
}

string cat::getName()
{
	return name;

}

void cat::getCount()
{
    cout << "The number of cats is " << count << endl;
}

void cat::speak()
{
    cout << "PURR" << endl;
}
///////////////////////////////

//Counts for all classes initialized to 0
int animal::count = 0;
int canine::count = 0;
int feline::count = 0;
int dog::count = 0;
int cat::count = 0;
int wolf::count = 0;