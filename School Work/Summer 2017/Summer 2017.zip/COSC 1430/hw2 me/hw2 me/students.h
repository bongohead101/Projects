#ifndef H_STUDENTS
#define H_STUDENTS

class student {
private:

	string name;
	int numCourses;
	string* courseList;
	double* gradeList;
	static int numStudents;

public:

	student();
	void setname(string);
	void setnumCourses(int);
	void setCourseList(string&);
	void setgradeList(double[]);





};






#endif // !H_STUDENTS
