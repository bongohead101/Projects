/*
final
in C++:
	midterm topics
	&
	overloading
	friend functions
	templates
	polymorphism
	exception handleing







*/