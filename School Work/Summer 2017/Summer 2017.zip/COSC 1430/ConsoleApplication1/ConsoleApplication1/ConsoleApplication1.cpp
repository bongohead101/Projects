// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream> // import input output
using namespace std; //standard


int main()
{
	for (int i = 0; i < 10; i++) {
		cout << i << endl;
	}

	system("pause");
	return 0;
}

