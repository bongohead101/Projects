#include "stdafx.h"
#include <iostream>
#include <time.h>
using namespace std;

double crand(int);

int main(int argc, char *argv[])
{
	srand(time(0));

	if (argc == 3) { //checks argument count

		if (argv[1] >= 0 && argv[2] >= 0){ //checks if arguments are positive
			
			int nrow = atoi(argv[1]);
			int ncol = atoi(argv[2]);
			double *p = new double[nrow];
			

			for (int i = 0; i < nrow; i++) {
				cout << p[i] << endl;
			}
			
			double** p2 = new double*[nrow];
			for (int i = 0; i < nrow; i++) {
				p2[i] = new double[ncol];
			}


			for (int i = 0; i < nrow; i++) {
				for (int j = 0; j < ncol; i++) {
					p2[i][j] = crand(i);
					cout << p2[i][j] << "\t";
				}
				cout << endl; 
			}








		}
		else { //error for negative numbers
			cout << "ERROR THIS PROGRAM ONLY ACCEPTS POSITIVE INTEGERS IN THE ARGUMENTS" << endl;
		}
	}
	else { // error for invalid number of arguments
		cout << "ERROR THIS PROGRAM ONLY ACCEPTS 2 INTEGER ARGUMENTS: \n (NUMBER OF ROWS , NUMBER OF COLLUMNS)" << endl;
	}





	system("pause");
    return 0;
}

double crand(int range=100) { //creates a random double
	double finish = rand() % (range) + 1;
	double dec = (rand() % 100);
	dec = dec / 100;
	finish = finish + dec;


	int temp = rand() % 2;
	if (temp == 0)
		return finish;
	else
		return finish*-1;
}


