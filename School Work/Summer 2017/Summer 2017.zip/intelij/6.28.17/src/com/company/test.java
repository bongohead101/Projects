package com.company;

import javax.swing.*;

/**
 * Created by marcc on 6/28/2017.
 */
public class test {
    private JPanel panel1;
    private JButton button;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
