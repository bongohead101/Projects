Marc Cardenas 1597234

use g++ -fpermissive -std=c++11 main.cpp -o main
use io-redirection for input