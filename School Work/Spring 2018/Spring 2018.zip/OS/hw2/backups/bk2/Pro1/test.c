#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void changechar(char[]);

int main(void) {
  char st[] ="Where there is will, there is a way.";
  printf("%s\n",st);
  changechar(st);
  printf("%s\n",st);

  return 0;
}

void changechar(char change[]){

	strcpy(change,"changed!");
}
