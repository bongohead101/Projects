#include <iostream>
#include "program.h"
using namespace std;

class cpu{
  public:
    cpu(int =1);
    int numcores,freecores;
    
    queue<int>* readyqueue;// pointers to respective queues to send the pointer objects through
    void setreadyqueue(queue<int>& a){readyqueue = &a;}
    
    
    //when writing input function set placetimefinish
    bool freecore();
    void insert(int, program*);// decides where a process should go
    void pull(int, program*); // put a process into the cpu
    void yank(int, list<program>&); // ment to be used in simulation while loop
    // void checkpoptime(int);
    
};

cpu::cpu(int a){
    numcores = a;
    freecores =a;
    readyqueue = new queue<int>;
    
}

bool cpu::freecore(){
    if(freecores > 0){return true;}
    else{return false;}
}

void cpu::insert(int simtime, program* cannidate){ // determines where the program should go
    /*
    1.check ready queue for items before trying to place into cpu set process state to blocked then put id number into queue
    2.if into cpu call into cpu function == set placetime ready, free cores--, change status
    */
    //cout << "cpu info: "<< (*readyqueue).empty() <<" " << freecore()<<endl;
    
    if((*readyqueue).empty() && freecore()){
        //call into cpu
        pull(simtime, cannidate);
    }else{//Process 2 must wait for a core
        cout <<"-- Process " << (*cannidate).ID << " must wait for a core"<<endl;
        (*cannidate).setstatus("BLOCKED");
        (*readyqueue).push((*cannidate).ID);//cout console message
        cout << "-- Ready queue now contains "<< (*readyqueue).size() << " process(es) waiting for a core"<<endl;//Ready queue now contains 1 process(es) waiting for a core
    }
    
}

void cpu::pull(int simtime, program* cannidate){ //pulls programs into the cpu
    cout <<"-- Process " <<(*cannidate).ID <<" will release a core at time "<<simtime + (*cannidate).pqueue ->front().eta<<" ms"<<endl;
    cannidate->setplacetimefinish(simtime);//= simtime + (*cannidate).pqueue -> front().eta; // sets placetimefinish in the program
    (*cannidate).setstatus("RUNNING"); // changes status to running
    --freecores; // show that a core is being used up
}

void cpu::yank(int simtime, list<program>& pros){ // check if something is in the ready queue first, and if there are free cores
    pull(simtime, (findid((*readyqueue).front(),pros)));
    (*readyqueue).pop();
}

class ssd{
  public:
    ssd(int =1);
    int numcores,freecores,ssdaccess;
    double ssdaveragehold;
    
    queue<int> *ssdqueue;// pointers to respective queues to send the pointer objects through
    void setssdqueue(queue<int>& a){ssdqueue = &a;}
    
    
    //when writing input function set placetimefinish
    bool freecore();
    void insert(int, program*);// decides where a process should go
    void pull(int, program*); // put a process into the cpu
    void yank(int, list<program>&); // ment to be used in simulation while loop
    // void checkpoptime(int);
    
};

ssd::ssd(int a){
    numcores = a;
    freecores =a;
    ssdaccess = 0;
    ssdaveragehold =0;
    ssdqueue = new queue<int>;
    
}

bool ssd::freecore(){ // checks if there are free resources to use
    if(freecores > 0){return true;}
    else{return false;}
}

void ssd::insert(int simtime, program* cannidate){ // decides where to put programs into
    /*
    1.check ready queue for items before trying to place into cpu set process state to blocked then put id number into queue
    2.if into cpu call into cpu function == set placetime ready, free cores--, change status
    */
    //cout << "cpu info: "<< (*readyqueue).empty() <<" " << freecore()<<endl;
    
    if((*ssdqueue).empty() && freecore()){
        //call into cpu
        pull(simtime, cannidate);
        
    }else{
        cout <<"-- Process " << (*cannidate).ID << " must wait for the SSD"<<endl;
        (*cannidate).setstatus("BLOCKED");
        (*ssdqueue).push((*cannidate).ID);//cout console message
        cout << "-- SSD queue now contains "<< (*ssdqueue).size() << " process(es) waiting for the SSD"<<endl;
    }
    
}

void ssd::pull(int simtime, program* cannidate){ // pulls programs into the ssd
    cout <<"-- Process " <<(*cannidate).ID <<" will relese the SSD at time "<<simtime + (*cannidate).pqueue ->front().eta<<" ms"<<endl;
    cannidate->setplacetimefinish(simtime);//= simtime + (*cannidate).pqueue -> front().eta; // sets placetimefinish in the program
    (*cannidate).setstatus("RUNNING"); // changes status to running
    --freecores; // show that a core is being used up
    
    ssdaveragehold+=(*cannidate).pqueue ->front().eta;
    ssdaccess++;
}

void ssd::yank(int simtime, list<program>& pros){ // check if something is in the ready queue first, and if there are free cores
    pull(simtime, (findid((*ssdqueue).front(),pros)));
    (*ssdqueue).pop();
}

class io{
  public:
    io(int =1);
    int numcores,freecores;
    
    queue<int> *ioqueue;// pointers to respective queues to send the pointer objects through
    void setioqueue(queue<int>& a){ioqueue = &a;}
    
    
    //when writing input function set placetimefinish
    bool freecore();
    void insert(int, program*);// decides where a process should go
    void pull(int, program*); // put a process into the cpu
    void yank(int, list<program>&); // ment to be used in simulation while loop
    // void checkpoptime(int);
    
};

io::io(int a){
    numcores = a;
    freecores =a;
    ioqueue = new queue<int>;
    
}

bool io::freecore(){ // function to check if the input is avalible
    if(freecores > 0){return true;}
    else{return false;}
}

void io::insert(int simtime, program* cannidate){ // function to determine where the program should go
    /*
    1.check ready queue for items before trying to place into cpu set process state to blocked then put id number into queue
    2.if into cpu call into cpu function == set placetime ready, free cores--, change status
    */
    //cout << "cpu info: "<< (*readyqueue).empty() <<" " << freecore()<<endl;
    
    if((*ioqueue).empty() && freecore()){
        //call into cpu
        pull(simtime, cannidate);
    }else{
        cout <<"-- Process " << (*cannidate).ID << " must wait for user"<<endl;
        (*cannidate).setstatus("BLOCKED");
        (*ioqueue).push((*cannidate).ID);//cout console message
        cout << "-- Input queue now contains "<< (*ioqueue).size() << " process(es) waiting for the user"<<endl;
    }
    
}

void io::pull(int simtime, program* cannidate){ // pull programs to the input
     cout <<"-- Process " <<(*cannidate).ID <<" will complete input at time "<<simtime + (*cannidate).pqueue ->front().eta<<" ms"<<endl;
    cannidate->setplacetimefinish(simtime);//= simtime + (*cannidate).pqueue -> front().eta; // sets placetimefinish in the program
    (*cannidate).setstatus("RUNNING"); // changes status to running
    --freecores; // show that a core is being used up
}

void io::yank(int simtime, list<program>& pros){ // check if something is in the ready queue first, and if there are free resources
    pull(simtime, (findid((*ioqueue).front(),pros)));
    (*ioqueue).pop();
}