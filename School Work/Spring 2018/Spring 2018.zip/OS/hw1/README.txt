Compile comand:
g++ -std=c++11 main.cpp -o main

the -o main can be called anything i had some problems when i compiled the program with gcc
no need to compile *.cpp because it is all included in the main.cpp file
