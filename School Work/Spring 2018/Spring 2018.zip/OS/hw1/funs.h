#include <iostream>
#include "cpu.h"
#include <list>
using namespace std;

void makelist(int& cpucores,list<program>& pros){//creates a list from the input data
    string a;
    int b;
    
    cin >> a >> b;
    cpucores = b;
    
    queue<info> tempqueue;
    while(cin >> a >>b){
        info holder;
        holder.place = a;
        holder.eta = b;
        tempqueue.push(holder);
    }
    int counter=0;
    while(!tempqueue.empty()){
        if(tempqueue.front().place == "NEW"){
            int ini = tempqueue.front().eta;
            queue<info>* procqueue;
            procqueue = new queue<info>;
            do{
                tempqueue.pop();
                if(!tempqueue.empty()&& tempqueue.front().place != "NEW" ){
                    procqueue->push(tempqueue.front());
                }
                
            }while(!tempqueue.empty()&& tempqueue.front().place != "NEW" );
            //to have an end flag
            info holder;
            holder.place = "END";
            holder.eta = 0;
            procqueue->push(holder);
            //insert to list
            program* tempprogram;
            tempprogram = new program(ini, procqueue,counter);
            counter++;
            pros.push_back(*tempprogram);
        }
        
    }
    
}

void keepcpubusy(int simtime, list<program>& active, cpu& cpus,ssd& ssds, io& ios){// keeps resources busy
    while(ssds.freecores>0 && !ssds.ssdqueue -> empty()){
        ssds.yank(simtime, active);
    }
    
    while(ios.freecores>0 && !ios.ioqueue -> empty()){
        ios.yank(simtime, active);
    }
    
    while(cpus.freecores>0 && !cpus.readyqueue -> empty()){
        cpus.yank(simtime, active);
    }
}

int findtime(int simtime, list<program>& pros, list<program>& active, cpu& cpus,ssd& ssds, io& ios,int& processcompleted){//finds smallest time in the active and inactive process lists //may want to also put inactive processesn into active
    int smallest=numeric_limits<int>::max();//numeric_limits<int>::max();
    for (auto iterator = pros.begin(), end = pros.end(); iterator != end;/* ++iterator*/) { //to go through the program list
    //((*iterator).starttime > simtime) << " " << ((*iterator).starttime < smallest)<<" "<< (*iterator).starttime<<" "<<"Smallest is: "<<smallest <<endl;
        if((*iterator).starttime == simtime){
            cout << "-- ARRIVAL event for process "<< (*iterator).ID<<" at time "<<simtime<<" ms \n"<<endl;//ARRIVAL event for process 1 at time 20 ms
            cout <<"Process "<<(*iterator).ID<<" starts at time "<<simtime<<" ms"<<endl;//Process 0 starts at time 10 ms
            for (auto temp = active.begin(), end = active.end(); temp != end; ++temp){
                cout << "Process " << (*temp).ID << " is "<<(*temp).getstatus()<<endl;
            }
            cout <<"\n";
            
            auto temp2 = iterator;
            iterator++;
            active.splice(active.end(),pros,temp2);
        }
        
        if((*iterator).starttime >= simtime && (*iterator).starttime < smallest){
            smallest = (*iterator).starttime;
            //place iterator into active list;
           
        }else{
            iterator++;
        }
    }
    for (auto iterator = active.begin(), end = active.end(); iterator != end; ++iterator) { //to go through the program list
        // when a precess is placed into the active queue and hasnt been set to a place/queue yet DO IT
        if((*iterator).placetimefinish == 0 && (*iterator).getstatus()!="BLOCKED"){//may need to change this for the ready queue
            auto temp = iterator;
            //cout << "Process ID: "<< (*iterator).ID << " needs to go to: "<< (*iterator).pqueue -> front().place<<endl;
            if((*iterator).pqueue -> front().place == "CORE"){// Process 0 requests a core at time 10 ms for 100 ms
                temp = iterator;
                cout << "-- Process "<<(*iterator).ID << " requests a core at time "<< simtime << " ms for "<< (*iterator).pqueue ->front().eta<<" ms"<<endl;
                cpus.insert(simtime, &(*iterator)); //run insert functions that will attempt to use cpu if not function will place id into the ready queue
            }else if((*iterator).pqueue -> front().place == "INPUT"){//Process 0 requests input from user at time 110 ms for 5000 ms
                cout << "-- Process "<< (*iterator).ID << " requests input from user at time "<<simtime <<" ms for "<<(*iterator).pqueue->front().eta<<" ms"<<endl;
                ios.insert(simtime, &(*iterator));         
            }else if((*iterator).pqueue -> front().place == "SSD"){
                cout << "-- Process "<<(*iterator).ID << "requests SSD access at time "<< simtime << " ms for "<< (*iterator).pqueue ->front().eta<< " ms"<<endl;
                ssds.insert(simtime, &(*iterator));
                
                    
            }else if((*iterator).pqueue -> front().place == "END"){  
                // need amount of processes that ended
                cout <<"\n";
                cout << "Process " << (*iterator).ID << " terminates at time "<<simtime<<" ms"<<endl;
                processcompleted++;
                    for (auto temp = active.begin(), end = active.end(); temp != end; ++temp){
                        if((*temp).ID == (*iterator).ID){
                            cout << "Process "<<(*temp).ID <<" is TERMINATED"<<endl;
                        }else{
                            cout << "Process " << (*temp).ID << " is "<<(*temp).getstatus()<<endl;
                        }
                    }
                cout <<"\n";
                iterator = active.erase(iterator);
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        //cout <<"Place time finish of Process "<< (*iterator).ID << " is " << (*iterator).placetimefinish<< " @ "<<(*iterator).pqueue -> front().place<<endl; 
        
        if((*iterator).placetimefinish > simtime && (*iterator).placetimefinish < smallest){
            smallest = (*iterator).placetimefinish;
        }
    }
    
    return smallest;
    
}

void freedevices(int simtime, list<program>& active, cpu& cpus,ssd& ssds, io& ios, int& processcompleted){ //passes simtime, list of active processes, cpu object, ssd object, and io object
    for (auto iterator = active.begin(), end = active.end(); iterator != end; ++iterator) { //to go through the program list
        // cout << "test 40" <<endl;
        //cout<<(*iterator).ID<<endl;
        if((*iterator).getstatus() != "BLOCKED" && (*iterator).getstatus() != "READY"){//(*iterator).getstatus() == "RUNNING"
            //cout << "Status: "<< (*iterator).getstatus()<<endl;
            if((*iterator).placetimefinish == simtime && (*iterator).placetimefinish >0){ // program leaving the place
                //runs export comand to next place
                
                (*iterator).setstatus("READY");
                //cout << "Process "<<(*iterator).ID<<": Time til finish: "<<(*iterator).placetimefinish<< " @ " <<(*iterator).pqueue -> front().place<<endl;
                    //to release an iem
                    if((*iterator).pqueue -> front().place == "CORE"){
                        cpus.freecores++;
                        cout <<"-- CORE completion event for process "<<(*iterator).ID<<" at time "<<simtime<<" ms"<<endl;
                        while(cpus.freecores>0 && !cpus.readyqueue -> empty()){
                            cpus.yank(simtime, active);
                        }
                        
                    } //cpu process is done a core is now freed
                    else if((*iterator).pqueue -> front().place == "SSD"){
                        ssds.freecores++;
                        cout <<"-- SSD completion event for process "<<(*iterator).ID<<" at time "<<simtime<<" ms"<<endl;
                        while(ssds.freecores>0 && !ssds.ssdqueue -> empty()){
                            ssds.yank(simtime, active);
                        }
                    }else if((*iterator).pqueue -> front().place == "INPUT"){
                        ios.freecores++;
                        cout <<"-- INPUT completion event for process "<<(*iterator).ID<<" at time "<<simtime<<" ms"<<endl;
                        while(ios.freecores>0 && !ios.ioqueue -> empty()){
                            ios.yank(simtime, active);
                        }
                    }
                
                //cout << (*iterator).pqueue ->front().place<<endl;
                // send the process to the next step
                (*iterator).pqueue -> pop();
                
                while((*iterator).pqueue->front().place != "END" && (*iterator).pqueue->front().eta == 0){ // if time needed in a place is 0
                    if((*iterator).pqueue -> front().place == "SSD"){
                        ssds.ssdaccess++;
                    }
                    (*iterator).pqueue->pop();
                }
                
                
                //cout << "Process "<<(*iterator).ID<<": NEW Time needed: "<<(*iterator).pqueue -> front().eta<< " @ " <<(*iterator).pqueue -> front().place<<endl;
                program* point = &(*iterator);
                
                if((*iterator).pqueue -> front().place == "CORE"){
                     cout << "-- Process "<<(*iterator).ID << " requests a core at time "<< simtime << " ms for "<< (*iterator).pqueue ->front().eta<<" ms"<<endl;
                    cpus.insert(simtime, point); //run insert functions that will attempt to use cpu if not function will place id into the ready queue
                    
                }else if((*iterator).pqueue -> front().place == "INPUT"){
                    cout << "-- Process "<< (*iterator).ID << " requests input from user at time "<<simtime <<" ms for "<<(*iterator).pqueue->front().eta<<" ms"<<endl;
                    ios.insert(simtime, point);
                }else if((*iterator).pqueue -> front().place == "SSD"){
                    cout << "-- Process "<<(*iterator).ID << " requests SSD access at time "<< simtime << " ms for "<< (*iterator).pqueue ->front().eta<< " ms"<<endl;
                    ssds.insert(simtime, point);
                }else if((*iterator).pqueue -> front().place == "END"){  
                    //Process 0 terminates at time 5668 ms
                    //Process 0 is TERMINATED
                    // need amount of processes that ended
                    cout << "\n";
                    cout << "Process " << (*iterator).ID << " terminates at time "<<simtime<<" ms"<<endl;
                    processcompleted++;
                    for (auto temp = active.begin(), end = active.end(); temp != end; ++temp){
                        if((*temp).ID == (*iterator).ID){
                            cout << "Process "<<(*temp).ID <<" is TERMINATED"<<endl;
                        }else{
                            cout << "Process " << (*temp).ID << " is "<<(*temp).getstatus()<<endl;
                        }
                    }
                    cout <<"\n";
                    
                    iterator = active.erase(iterator);
                    
                }
                
            }
            
        }
    }
    
}


