#include <iostream>
#include <queue>
#include <list>
#include <limits>

using namespace std;

struct info{
    string place;
    int eta;
    
};

class program{
    public:
        program();
        program(int,queue<info>*, int);
        int starttime,ID;
        // status
        int status; // 1. running / 0. ready / -1. blocked
        int placetimefinish; // holds system time when process is finished
        
        queue<info>* pqueue;
        
        void printall();
        void setplacetimefinish(int);
        string getstatus();
        void setstatus(string);
};

program::program(){
    
}

program::program(int a, queue<info>* b, int count){
    starttime = a;
    pqueue = b;
    ID = count;
    status = 0;
    placetimefinish = 0;
}

void program::printall(){ // prints the process id and all the processes left (will erase the processes left)
    while(!pqueue->empty()){
        cout << "Process "<<ID<<endl;
        cout << pqueue->front().place <<" "<< pqueue->front().eta <<endl;
        pqueue->pop();
    }
    
}

void program::setstatus(string a){ // set status of the program
    
    if(a == "READY" || a == "0"){status = 0;}
    else if(a == "RUNNING" || a == "1"){status = 1;}
    else if(a == "BLOCKED" || a == "-1"){status = -1;}
    else{status = 0;}
    
}

string program::getstatus(){ // returns the status of the program
    
    if(status == 0){
        return "READY";
    }else if(status == 1){
        return "RUNNING";
    }else if(status == -1){
        return "BLOCKED";
    }else{
        cout << "Status Error ... Status: "<<status<<endl;
        return "Error";
        
    }
    
}

void program::setplacetimefinish(int simtime){ // sets the amount of time a program will take 
    placetimefinish = simtime + pqueue->front().eta;
}

program* findid(int a, list<program>& pros){ // non member function that looks within a list to find an ID match and returns a pointer to that program
    program* point;
    for (auto iterator = pros.begin(), end = pros.end(); iterator != end; ++iterator) { //to go through the program list
        if((*iterator).ID == a){
            point = &(*iterator);
            return point;
        }
    }
    
} // finds id of a program within a list and returns a pointer to that program