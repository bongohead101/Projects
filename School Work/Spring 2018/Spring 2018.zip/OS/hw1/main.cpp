/*
Marc Cardenas 1597234
Assignment #1: Process Scheduling
COSC 3360
2/23/2018

Description:
    Simulate the scheduling process by simulating the interactions between the cpu, ssd and input device

*/

#include <iostream>
#include "funs.h"
using namespace std;

int main(){
    
    list<program> pros, active;
    
    
    int cpucores;
    int simtime =0;    
    int processcompleted =0;

    makelist(cpucores,pros);
    cpu cpus(cpucores);
    ssd ssds(1);
    io ios(1);
    
    int i = 0;
    while(!pros.empty() || !active.empty()){
        /*
        find lowest time in pros, active list placetimeready
        */
        simtime = findtime(simtime, pros,active,cpus,ssds,ios,processcompleted);
        //cout << "Sim time is: "<<simtime<<endl;
        keepcpubusy(simtime,active,cpus,ssds,ios);
        freedevices(simtime,active,cpus,ssds,ios,processcompleted);
        
        // i++;
        // if(i ==100){
        //     exit(0);
        // }
    }
    
    cout << "Summary:\nNumber of processes that completed: " << processcompleted<< "\nTotal number of SSD accesses: "<<ssds.ssdaccess<<"\nAverage SSD access time: "<<ssds.ssdaveragehold/ssds.ssdaccess
    <<" ms\nTotal elapsed time: "<<simtime<<" ms"<<endl;
    
    return 0;
}

